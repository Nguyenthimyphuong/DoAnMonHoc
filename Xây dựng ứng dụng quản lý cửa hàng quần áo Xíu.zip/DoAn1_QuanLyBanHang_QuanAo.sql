﻿USE master
DROP DATABASE IF EXISTS DoAn1_QuanLyBanHang_QuanAo
GO

CREATE DATABASE DoAn1_QuanLyBanHang_QuanAo
USE DoAn1_QuanLyBanHang_QuanAo
GO

--Tạo bảng Tài khoản
CREATE TABLE TBL_TaiKhoan
(
	MaTK INT NOT NULL,
	TaiKhoan NVARCHAR(50) NOT NULL,
	MatKhau NVARCHAR(50) NOT NULL,
	PerID INT NOT NULL,
	CONSTRAINT PK_TaiKhoan PRIMARY KEY(MaTK)
);
GO

--Tạo bảng Loại hàng
CREATE TABLE LoaiHang
(
	MaLH NVARCHAR(10) PRIMARY KEY,
    TenLH NVARCHAR(50) NOT NULL,
    MoTa NVARCHAR(200),
	IsDeleted BIT NOT NULL DEFAULT 0,
);
GO

--Tạo bảng Sản phẩm
CREATE TABLE SanPham
(
    MaSP NVARCHAR(10) PRIMARY KEY,
    TenSP NVARCHAR(100) NOT NULL,
    MaLH NVARCHAR(10),
    DonGiaBan DECIMAL(18, 2),
    SoLuong INT,
    MoTa NVARCHAR(200),
    HinhAnh NVARCHAR(255),
	IsDeleted BIT NOT NULL DEFAULT 0,
    FOREIGN KEY (MaLH) REFERENCES LoaiHang(MaLH)
);
GO

-- Tạo bảng Nhà cung cấp
CREATE TABLE NhaCungCap
(
	MaNCC NVARCHAR(10) PRIMARY KEY,
    TenNCC NVARCHAR(100) NOT NULL,
    DiaChi NVARCHAR(200),
    SoDienThoai NVARCHAR(15),
	IsDeleted BIT NOT NULL DEFAULT 0,
);
GO

-- Tạo bảng Đơn hàng nhập
CREATE TABLE DonHangNhap
(
	MaDHN NVARCHAR(10) PRIMARY KEY,
    MaNCC NVARCHAR(10),
    NgayNhap DATETIME,
    TongTien DECIMAL(18, 2),
    FOREIGN KEY (MaNCC) REFERENCES NhaCungCap(MaNCC)
);
GO

-- Tạo bảng Chi tiết đơn hàng nhập
CREATE TABLE ChiTietDonHangNhap
(
	MaCTDHN INT PRIMARY KEY IDENTITY(1,1),
    MaDHN NVARCHAR(10),
    MaSP NVARCHAR(10),
    SoLuong INT,
    DonGia DECIMAL(18, 2),
	ThanhTien DECIMAL(18, 2),
    FOREIGN KEY (MaDHN) REFERENCES DonHangNhap(MaDHN) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);
GO

-- Tạo bảng Khách hàng
CREATE TABLE KhachHang
(
	MaKH NVARCHAR(10) PRIMARY KEY,
    TenKH NVARCHAR(100) NOT NULL,
    SoDienThoai NVARCHAR(15),
    DiaChi NVARCHAR(200),
	Gmail NVARCHAR(200),
	IsDeleted BIT NOT NULL DEFAULT 0,
);
GO

-- Tạo bảng Đơn hàng bán
CREATE TABLE DonHangBan
(
	MaDHB NVARCHAR(10) PRIMARY KEY,
    MaKH NVARCHAR(10),
    NgayBan DATETIME,
    TongTien DECIMAL(18, 2),
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH)
);
GO

-- Tạo bảng Chi tiết đơn hàng bán
CREATE TABLE ChiTietDonHangBan
(
	MaCTDHB INT PRIMARY KEY IDENTITY(1,1),
    MaDHB NVARCHAR(10),
    MaSP NVARCHAR(10),
    SoLuong INT,
    DonGia DECIMAL(18, 2),
	ThanhTien DECIMAL(18, 2),
    FOREIGN KEY (MaDHB) REFERENCES DonHangBan(MaDHB) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);
GO

-- Tạo bảng Nhân viên
CREATE TABLE NhanVien
(
    MaNV NVARCHAR(10) PRIMARY KEY,
    TenNV NVARCHAR(100) NOT NULL,
    GioiTinh BIT,  -- 1 = Nam, 0 = Nữ
    NgaySinh DATE,
    DiaChi NVARCHAR(200),
    SoDienThoai NVARCHAR(15)
);
GO

-- Câu lệnh SELECT
SELECT * FROM TBL_TaiKhoan;
SELECT * FROM LoaiHang;
SELECT * FROM SanPham;
SELECT * FROM NhaCungCap;
SELECT * FROM DonHangNhap;
SELECT * FROM ChiTietDonHangNhap;
SELECT * FROM KhachHang;
SELECT * FROM DonHangBan;
SELECT * FROM ChiTietDonHangBan;
SELECT * FROM NhanVien;

--Insert table TBL_TaiKhoan
INSERT INTO TBL_TaiKhoan (MaTK, TaiKhoan, MatKhau, PerID) VALUES (1, 'admin', '123', 1)
INSERT INTO TBL_TaiKhoan (MaTK, TaiKhoan, MatKhau, PerID) VALUES (2, 'nv1', '123', 0)

--Insert Loại hàng
INSERT INTO LoaiHang (MaLH, TenLH, MoTa)
VALUES
('LH01', N'Áo Thun', N'Áo thun thời trang nam nữ'),
('LH02', N'Quần Jean', N'Quần jean cao cấp cho mọi lứa tuổi'),
('LH03', N'Đầm/Váy', N'Đầm váy nữ đủ kiểu dáng');
GO



--Insert Sản phẩm
INSERT INTO SanPham (MaSP, TenSP, MaLH, DonGiaBan, SoLuong, MoTa, HinhAnh)
VALUES
('SP01', N'Áo Thun Trơn Trắng', 'LH01', 150000, 100, N'Áo thun cotton trắng trơn', NULL),
('SP02', N'Áo Thun In Hình', 'LH01', 180000, 80, N'Áo thun unisex in hình sáng tạo', NULL),
('SP03', N'Quần Jean Rách Gối', 'LH02', 350000, 60, N'Quần jean nam phong cách cá tính', NULL),
('SP04', N'Quần Jean Lưng Cao', 'LH02', 370000, 50, N'Quần jean nữ lưng cao form đẹp', NULL),
('SP05', N'Váy Hoa Dài', 'LH03', 420000, 40, N'Đầm hoa dáng dài nữ tính', NULL),
('SP06', N'Váy Xòe Ngắn', 'LH03', 390000, 70, N'Đầm xòe ngắn năng động', NULL),
('SP07', N'Áo Thun Dài Tay', 'LH01', 200000, 90, N'Áo thun dài tay unisex', NULL),
('SP08', N'Quần Jean Slimfit', 'LH02', 360000, 55, N'Jean ôm nam trẻ trung', NULL),
('SP09', N'Đầm Ôm Body', 'LH03', 450000, 30, N'Đầm ôm body quyến rũ', NULL),
('SP10', N'Áo Thun Form Rộng', 'LH01', 170000, 75, N'Áo thun form rộng phong cách Hàn', NULL);
GO



--Insert Nhà cung cấp
INSERT INTO NhaCungCap (MaNCC, TenNCC, DiaChi, SoDienThoai)
VALUES
('NCC01', N'Công ty Thời Trang ABC', N'123 Trần Duy Hưng, Hà Nội', '0912345678'),
('NCC02', N'Công ty Dệt May Hà Nội', N'456 Nguyễn Trãi, Hà Nội', '0987654321');
GO



--Insert Đơn hàng nhập
INSERT INTO DonHangNhap (MaDHN, MaNCC, NgayNhap, TongTien)
VALUES
('DHN01', 'NCC01', '2025-04-20', NULL),
('DHN02', 'NCC02', '2025-04-22', NULL),
('DHN03', 'NCC01', '2025-04-23', NULL),
('DHN04', 'NCC02', '2025-04-26', NULL),
('DHN05', 'NCC01', '2025-04-27', NULL),
('DHN06', 'NCC02', '2025-04-28', NULL),
('DHN07', 'NCC01', '2025-04-29', NULL),
('DHN08', 'NCC02', '2025-04-30', NULL),
('DHN09', 'NCC01', '2025-05-01', NULL),
('DHN10', 'NCC02', '2025-05-02', NULL);
GO


--Insert Chi tiết đơn hàng nhập
INSERT INTO ChiTietDonHangNhap (MaDHN, MaSP, SoLuong, DonGia, ThanhTien)
VALUES
('DHN01', 'SP01', 50, 75000, 3750000),
('DHN01', 'SP02', 30, 90000, 2700000),
('DHN02', 'SP03', 40, 180000, 7200000),
('DHN03', 'SP04', 25, 190000, 4750000),
('DHN04', 'SP05', 20, 210000, 4200000),
('DHN05', 'SP06', 40, 195000, 7800000),
('DHN06', 'SP07', 60, 100000, 6000000),
('DHN07', 'SP08', 35, 180000, 6300000),
('DHN08', 'SP09', 20, 230000, 4600000),
('DHN09', 'SP10', 30, 85000, 2550000),
('DHN10', 'SP01', 40, 75000, 3000000);
GO


--Insert Khách hàng
INSERT INTO KhachHang (MaKH, TenKH, SoDienThoai, DiaChi, Gmail)
VALUES
('KH01', N'Nguyễn Văn Dũng', '0901234567', N'12 Nguyễn Trãi, Hà Đông, Hà Nội', 'dung@gmail.com'),
('KH02', N'Hà Thị Thơm', '0907654321', N'15 Hoàng Liệt, Hoàng Mai, Hà Nội', 'thom@gmail.com'),
('KH03', N'Trần Văn Kiên', '0911111111', N'Long Biên, Hà Nội', 'kien@gmail.com'),
('KH04', N'Phạm Thị Hoa', '0922222222', N'Cầu Giấy, Hà Nội', 'hoa@gmail.com'),
('KH05', N'Hoàng Đức', '0933333333', N'Đống Đa, Hà Nội', 'duc@gmail.com'),
('KH06', N'Lê Mai', '0944444444', N'Thanh Xuân, Hà Nội', 'mai@gmail.com'),
('KH07', N'Ngô Hải', '0955555555', N'Hà Đông, Hà Nội', 'hai@gmail.com'),
('KH08', N'Trịnh Lan', '0966666666', N'Ba Đình, Hà Nội', 'lan@gmail.com'),
('KH09', N'Đào Duy', '0977777777', N'Tây Hồ, Hà Nội', 'duy@gmail.com'),
('KH10', N'Nguyễn Tâm', '0988888888', N'Sơn Tây, Hà Nội', 'tam@gmail.com');
GO

--Insert Đơn hàng bán
INSERT INTO DonHangBan (MaDHB, MaKH, NgayBan, TongTien)
VALUES
('DHB01', 'KH01', '2025-04-24', NULL),
('DHB02', 'KH02', '2025-04-25', NULL),
('DHB03', 'KH03', '2025-04-26', NULL),
('DHB04', 'KH04', '2025-04-26', NULL),
('DHB05', 'KH05', '2025-04-27', NULL),
('DHB06', 'KH06', '2025-04-27', NULL),
('DHB07', 'KH07', '2025-04-28', NULL),
('DHB08', 'KH08', '2025-04-29', NULL),
('DHB09', 'KH09', '2025-05-01', NULL),
('DHB10', 'KH10', '2025-05-02', NULL);
GO


-- Insert Chi tiết đơn hàng bán (tự động lấy DonGia từ bảng SanPham)
INSERT INTO ChiTietDonHangBan (MaDHB, MaSP, SoLuong, DonGia, ThanhTien)
SELECT 'DHB01', 'SP01', 2, sp.DonGiaBan, 2 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP01'
UNION ALL
SELECT 'DHB01', 'SP02', 1, sp.DonGiaBan, 1 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP02'
UNION ALL
SELECT 'DHB02', 'SP03', 1, sp.DonGiaBan, 1 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP03'
UNION ALL
SELECT 'DHB02', 'SP04', 1, sp.DonGiaBan, 1 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP04'
UNION ALL
SELECT 'DHB03', 'SP05', 2, sp.DonGiaBan, 2 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP05'
UNION ALL
SELECT 'DHB04', 'SP06', 3, sp.DonGiaBan, 3 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP06'
UNION ALL
SELECT 'DHB05', 'SP07', 2, sp.DonGiaBan, 2 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP07'
UNION ALL
SELECT 'DHB06', 'SP08', 1, sp.DonGiaBan, 1 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP08'
UNION ALL
SELECT 'DHB07', 'SP09', 2, sp.DonGiaBan, 2 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP09'
UNION ALL
SELECT 'DHB08', 'SP10', 3, sp.DonGiaBan, 3 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP10'
UNION ALL
SELECT 'DHB09', 'SP01', 1, sp.DonGiaBan, 1 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP01'
UNION ALL
SELECT 'DHB10', 'SP02', 2, sp.DonGiaBan, 2 * sp.DonGiaBan FROM SanPham sp WHERE sp.MaSP = 'SP02';
GO



-- Insert Nhân viên
INSERT INTO NhanVien (MaNV, TenNV, GioiTinh, NgaySinh, DiaChi, SoDienThoai)
VALUES
('NV01', N'Nguyễn Văn An', 1, '1995-05-20', N'123 Lý Thường Kiệt, Hà Nội', '0901234567'),
('NV02', N'Lê Thị Bình', 0, '1998-03-15', N'45 Nguyễn Trãi, Hà Nội', '0907654321'),
('NV03', N'Phạm Văn Hùng', 1, '1992-01-10', N'Hoàng Mai, Hà Nội', '0911222333'),
('NV04', N'Nguyễn Thị Hạnh', 0, '1990-12-05', N'Đống Đa, Hà Nội', '0911333444'),
('NV05', N'Lê Văn Phú', 1, '1989-07-20', N'Cầu Giấy, Hà Nội', '0911444555'),
('NV06', N'Ngô Thị Hằng', 0, '1994-08-18', N'Thanh Xuân, Hà Nội', '0911555666'),
('NV07', N'Trịnh Văn Tuấn', 1, '1996-09-12', N'Long Biên, Hà Nội', '0911666777'),
('NV08', N'Hoàng Lan', 0, '1993-11-01', N'Ba Đình, Hà Nội', '0911777888'),
('NV09', N'Trần Thị Huyền', 0, '1997-03-03', N'Tây Hồ, Hà Nội', '0911888999'),
('NV10', N'Đỗ Văn Nam', 1, '1991-06-06', N'Sơn Tây, Hà Nội', '0911999000');
GO











--Stored Procedure kiểm tra đăng nhập
CREATE PROCEDURE SP_CheckDangNhap
@Username NVARCHAR(50),
@Password NVARCHAR(50)
AS
BEGIN	
    IF EXISTS ( SELECT * FROM dbo.TBL_TaiKhoan WHERE TaiKhoan = @Username AND MatKhau = @Password AND PerID = 1)
		SELECT 1 AS code -- Quyền Admin
	ELSE IF EXISTS ( SELECT * FROM dbo.TBL_TaiKhoan WHERE TaiKhoan = @Username AND MatKhau = @Password AND PerID = 0)
		SELECT 0 AS code -- Quyền User
	ELSE IF EXISTS ( SELECT * FROM dbo.TBL_TaiKhoan WHERE TaiKhoan = @Username AND MatKhau != @Password)
		SELECT 2 AS code
	ELSE
		SELECT 3 AS code
END

GO

--Stored Procedure đổi mật khẩu
CREATE PROCEDURE SP_ChangePassword
    @Username NVARCHAR(50),
    @OldPassword NVARCHAR(50),
    @NewPassword NVARCHAR(50)
AS
BEGIN
    -- Kiểm tra xem tài khoản có tồn tại và mật khẩu cũ chính xác hay không
    IF EXISTS (SELECT * FROM TBL_TaiKhoan WHERE TaiKhoan = @Username AND MatKhau = @OldPassword)
    BEGIN
        -- Cập nhật mật khẩu mới
        UPDATE TBL_TaiKhoan
        SET MatKhau = @NewPassword
        WHERE TaiKhoan = @Username

        -- Trả về giá trị thành công (1)
        SELECT 1
    END
    ELSE
    BEGIN
        -- Trả về giá trị lỗi (-1) nếu tài khoản không tồn tại hoặc mật khẩu cũ không chính xác
        SELECT -1
    END
END

GO

-- Trigger tự động cập nhật tổng tiền trong bảng Đơn Hàng Bán
CREATE TRIGGER TRG_CapNhatTongTien_DHB
ON ChiTietDonHangBan
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    -- Cập nhật tổng tiền cho các đơn hàng bị ảnh hưởng
    UPDATE DonHangBan
    SET TongTien = (
        SELECT SUM(ThanhTien)
        FROM ChiTietDonHangBan
        WHERE ChiTietDonHangBan.MaDHB = DonHangBan.MaDHB
    )
    WHERE MaDHB IN (
        SELECT MaDHB FROM inserted
        UNION
        SELECT MaDHB FROM deleted
    );
END;
GO

-- Trigger tự động cập nhật tổng tiền trong bảng Đơn Hàng Nhập
CREATE TRIGGER TRG_CapNhatTongTien_DHN
ON ChiTietDonHangNhap
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    -- Cập nhật tổng tiền cho các đơn hàng bị ảnh hưởng
    UPDATE DonHangNhap
    SET TongTien = (
        SELECT SUM(ThanhTien)
        FROM ChiTietDonHangNhap
        WHERE ChiTietDonHangNhap.MaDHN = DonHangNhap.MaDHN
    )
    WHERE MaDHN IN (
        SELECT MaDHN FROM inserted
        UNION
        SELECT MaDHN FROM deleted
    );
END;
GO

-- Stored thống kê doanh thu theo ngày
CREATE PROCEDURE SP_BaoCaoDoanhThu_Ngay
    @Ngay DATE
AS
BEGIN
    SELECT DHB.MaDHB, KH.TenKH, DHB.NgayBan, DHB.TongTien
    FROM DonHangBan DHB
    JOIN KhachHang KH ON KH.MaKH = DHB.MaKH
    WHERE CAST(DHB.NgayBan AS DATE) = @Ngay
END
GO

-- Stored thống kê doanh thu theo tháng
CREATE PROCEDURE SP_BaoCaoDoanhThu_Thang
    @Thang INT,
    @Nam INT
AS
BEGIN
    SELECT DHB.MaDHB, KH.TenKH, DHB.NgayBan, DHB.TongTien
    FROM DonHangBan DHB
    JOIN KhachHang KH ON KH.MaKH = DHB.MaKH
    WHERE MONTH(DHB.NgayBan) = @Thang AND YEAR(DHB.NgayBan) = @Nam
END
GO

-- Stored thống kê doanh thu theo năm
CREATE PROCEDURE SP_BaoCaoDoanhThu_Nam
    @Nam INT
AS
BEGIN
    SELECT DHB.MaDHB, KH.TenKH, DHB.NgayBan, DHB.TongTien
    FROM DonHangBan DHB
    JOIN KhachHang KH ON KH.MaKH = DHB.MaKH
    WHERE YEAR(DHB.NgayBan) = @Nam
END
GO


---------THE END



SELECT 
    MaNV, 
    TenNV, 
    CASE GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
    NgaySinh, 
    DiaChi, 
    SoDienThoai
FROM NhanVien;


SELECT 
    DHB.MaDHB, 
    DHB.MaKH, 
    DHB.NgayBan, 
    DHB.TongTien, 
    CTDHB.MaSP, 
    CTDHB.SoLuong, 
    CTDHB.DonGia, 
    CTDHB.ThanhTien
FROM 
    DonHangBan DHB
JOIN 
    ChiTietDonHangBan CTDHB ON DHB.MaDHB = CTDHB.MaDHB;


