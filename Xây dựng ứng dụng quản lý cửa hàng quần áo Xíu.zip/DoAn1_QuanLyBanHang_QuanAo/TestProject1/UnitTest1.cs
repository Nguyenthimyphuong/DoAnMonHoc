﻿using BLL;
using Castle.Components.DictionaryAdapter.Xml;
using DAL.Interface;
using DTO;
using Moq;
using NUnit.Framework.Internal;
using System.Data;

namespace TestProject1
{
    public class Tests
    {
        private Mock<IDAL_SanPham> _dalSanPhamMock;
        private BLL_SanPham _bllSanPham;

        [SetUp]
        public void Setup()
        {
            _dalSanPhamMock = new Mock<IDAL_SanPham>();
            _bllSanPham = new BLL_SanPham(_dalSanPhamMock.Object);
        }

        // Test kiểm tra GetAllSanPham trả về đúng DataTable từ DAL
        [Test]
        public void Test_GetAllSanPham_ShouldReturnDataTable()
        {
            var expectedTable = new DataTable();
            expectedTable.Columns.Add("MaSP");
            expectedTable.Rows.Add("SP001");

            _dalSanPhamMock.Setup(d => d.GetAllSanPham()).Returns(expectedTable);

            var result = _bllSanPham.GetAllSanPham();

            Assert.IsNotNull(result);
            Assert.AreEqual("SP001", result.Rows[0]["MaSP"]);
        }

        // Test kiểm tra Thêm sản phẩm thành công (DAL trả về true)
        [Test]
        public void Test_ThemSanPham_ShouldReturnTrue_WhenInsertSuccess()
        {
            var sp = new DTO_SanPham { MaSP = "SP001", TenSP = "Sản phẩm test" };

            _dalSanPhamMock.Setup(d => d.ThemSanPham(sp)).Returns(true);

            var result = _bllSanPham.ThemSanPham(sp);

            Assert.IsTrue(result);
        }

        // Test kiểm tra Thêm sản phẩm thất bại (DAL trả về false)
        [Test]
        public void Test_ThemSanPham_ShouldReturnFalse_WhenInsertFails()
        {
            var sp = new DTO_SanPham { MaSP = "SP001", TenSP = "Sản phẩm trùng mã" };

            _dalSanPhamMock.Setup(d => d.ThemSanPham(sp)).Returns(false);

            var result = _bllSanPham.ThemSanPham(sp);

            Assert.IsFalse(result);
        }

        // Test kiểm tra sửa sản phẩm thành công
        [Test]
        public void Test_SuaSanPham_ShouldReturnTrue()
        {
            var sp = new DTO_SanPham { MaSP = "SP001", TenSP = "Đã sửa" };

            _dalSanPhamMock.Setup(d => d.SuaSanPham(sp)).Returns(true);

            var result = _bllSanPham.SuaSanPham(sp);

            Assert.IsTrue(result);
        }

        // Test kiểm tra xóa sản phẩm thành công
        [Test]
        public void Test_XoaSanPham_ShouldReturnTrue()
        {
            var maSP = "SP001";

            _dalSanPhamMock.Setup(d => d.XoaSanPham(maSP)).Returns(true);

            var result = _bllSanPham.XoaSanPham(maSP);

            Assert.IsTrue(result);
        }

        // Test kiểm tra xóa sản phẩm thành công
        [Test]
        public void Test_TimKiemSanPham_ShouldReturnFilteredData()
        {
            var maSP = "SP001";
            var tenSP = "Test";

            var expectedTable = new DataTable();
            expectedTable.Columns.Add("MaSP");
            expectedTable.Columns.Add("TenSP");
            expectedTable.Rows.Add("SP001", "Sản phẩm Test");

            _dalSanPhamMock.Setup(d => d.TimKiemSanPham(maSP, tenSP)).Returns(expectedTable);

            var result = _bllSanPham.TimKiemSanPham(maSP, tenSP);

            Assert.IsNotNull(result);
            Assert.AreEqual("SP001", result.Rows[0]["MaSP"]);
        }

        // Test kiểm tra lấy đơn giá bán đúng theo mã sản phẩm
        [Test]
        public void Test_GetDonGiaBanSP_ShouldReturnCorrectPrice()
        {
            var maSP = "SP001";
            decimal expectedPrice = 50000;

            _dalSanPhamMock.Setup(d => d.GetDonGiaBanSP(maSP)).Returns(expectedPrice);

            var result = _bllSanPham.GetDonGiaBanSP(maSP);

            Assert.AreEqual(50000, result);
        }
    }
}
