﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    // Lớp DTO_NhanVien dùng để truyền dữ liệu giữa các lớp DAL, BLL và GUI
    public class DTO_NhanVien
    {
        public string MaNV { get; set; }
        public string TenNV { get; set; }
        public bool GioiTinh { get; set; } // true = Nam, false = Nữ
        public DateTime NgaySinh { get; set; }
        public string DiaChi { get; set; }
        public string SoDienThoai { get; set; }

        // Constructor không tham số
        public DTO_NhanVien() { }

        // Constructor có tham số
        public DTO_NhanVien(string maNV, string tenNV, bool gioiTinh, DateTime ngaySinh, string diaChi, string soDienThoai)
        {
            this.MaNV = maNV;
            this.TenNV = tenNV;
            this.GioiTinh = gioiTinh;
            this.NgaySinh = ngaySinh;
            this.DiaChi = diaChi;
            this.SoDienThoai = soDienThoai;
        }
    }
}
