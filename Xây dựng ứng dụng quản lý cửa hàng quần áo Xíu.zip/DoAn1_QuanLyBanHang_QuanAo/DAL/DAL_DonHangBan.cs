﻿using DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_DonHangBan : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        // Lấy danh sách tất cả đơn hàng bán
        public DataTable GetAllDonHangBan()
        {
            _con.Open();
            string query = @"
                SELECT dhb.MaDHB, dhb.MaKH, kh.TenKH, dhb.NgayBan, dhb.TongTien
                FROM DonHangBan dhb
                JOIN KhachHang kh ON dhb.MaKH = kh.MaKH";

            da = new SqlDataAdapter(query, _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Hàm thực thi câu lệnh SQL chung
        void thucthisql(string sql)
        {
            _con.Open();
            cmd = new SqlCommand(sql, _con);
            cmd.ExecuteNonQuery();
            _con.Close();
        }

        // Kiểm tra mã đơn hàng bán trùng
        public int KiemTraMaTrung(string maDHB)
        {
            _con.Open();
            string sql = $"SELECT COUNT(*) FROM DonHangBan WHERE MaDHB = '{maDHB.Trim()}'";
            cmd = new SqlCommand(sql, _con);
            int count = (int)cmd.ExecuteScalar();
            _con.Close();
            return count;
        }

        // Thêm đơn hàng bán
        public bool ThemDonHangBan(DTO_DonHangBan dhb)
        {
            if (KiemTraMaTrung(dhb.MaDHB) > 0)
            {
                return false; // Mã đơn hàng đã tồn tại
            }
            else
            {
                string sql = $"INSERT INTO DonHangBan (MaDHB, MaKH, NgayBan, TongTien) " +
                             $"VALUES ('{dhb.MaDHB}', '{dhb.MaKH}', '{dhb.NgayBan:yyyy-MM-dd}', {dhb.TongTien})";
                thucthisql(sql);
                return true;
            }
        }

        // Sửa đơn hàng bán
        public bool SuaDonHangBan(DTO_DonHangBan dhb)
        {
            string sql = $"UPDATE DonHangBan SET " +
                         $"MaKH = '{dhb.MaKH}', " +
                         $"NgayBan = '{dhb.NgayBan:yyyy-MM-dd}', " +
                         $"TongTien = {dhb.TongTien} " +
                         $"WHERE MaDHB = '{dhb.MaDHB}'";

            thucthisql(sql);
            return true;
        }

        // Xóa đơn hàng bán
        public bool XoaDonHangBan(string maDHB)
        {
            string sql = $"DELETE FROM DonHangBan WHERE MaDHB = '{maDHB}'";
            thucthisql(sql);
            return true;
        }

        // Tìm kiếm đơn hàng bán theo mã đơn hoặc mã khách
        public DataTable TimKiemDonHangBan(string maDHB, string maKH)
        {
            _con.Open();
            string sql = @"
                SELECT dhb.MaDHB, dhb.MaKH, kh.TenKH, dhb.NgayBan, dhb.TongTien
                FROM DonHangBan dhb
                JOIN KhachHang kh ON dhb.MaKH = kh.MaKH
                WHERE dhb.MaDHB LIKE @maDHB AND dhb.MaKH LIKE @maKH";

            da = new SqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("@maDHB", "%" + maDHB + "%");
            da.SelectCommand.Parameters.AddWithValue("@maKH", "%" + maKH + "%");

            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }
    }
}
