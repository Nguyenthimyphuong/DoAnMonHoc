﻿using DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_NhanVien : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        // Lấy tất cả nhân viên
        public DataTable GetAllNhanVien()
        {
            _con.Open();
            da = new SqlDataAdapter("SELECT * FROM NhanVien", _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Hàm thực thi câu lệnh SQL chung
        void thucthisql(string sql)
        {
            _con.Open();
            cmd = new SqlCommand(sql, _con);
            cmd.ExecuteNonQuery();
            _con.Close();
        }

        // Kiểm tra mã nhân viên trùng
        public int KiemTraMaTrung(string maNV)
        {
            _con.Open();
            string sql = $"SELECT COUNT(*) FROM NhanVien WHERE MaNV = '{maNV.Trim()}'";
            cmd = new SqlCommand(sql, _con);
            int count = (int)cmd.ExecuteScalar();
            _con.Close();
            return count;
        }

        // Thêm nhân viên
        public bool ThemNhanVien(DTO_NhanVien nhanVien)
        {
            if (KiemTraMaTrung(nhanVien.MaNV) > 0)
            {
                return false; // Mã nhân viên đã tồn tại
            }
            else
            {
                string sql = $"INSERT INTO NhanVien (MaNV, TenNV, GioiTinh, NgaySinh, DiaChi, SoDienThoai) " +
                             $"VALUES ('{nhanVien.MaNV}', N'{nhanVien.TenNV}', '{(nhanVien.GioiTinh ? 1 : 0)}', '{nhanVien.NgaySinh:yyyy-MM-dd}', N'{nhanVien.DiaChi}', '{nhanVien.SoDienThoai}')";
                thucthisql(sql);
                return true;
            }
        }

        // Sửa nhân viên
        public bool SuaNhanVien(DTO_NhanVien nhanVien)
        {
            string sql = $"UPDATE NhanVien SET " +
                         $"TenNV = N'{nhanVien.TenNV}', " +
                         $"GioiTinh = '{(nhanVien.GioiTinh ? 1 : 0)}', " +
                         $"NgaySinh = '{nhanVien.NgaySinh:yyyy-MM-dd}', " +
                         $"DiaChi = N'{nhanVien.DiaChi}', " +
                         $"SoDienThoai = '{nhanVien.SoDienThoai}' " +
                         $"WHERE MaNV = '{nhanVien.MaNV}'";

            thucthisql(sql);
            return true;
        }

        // Xóa nhân viên
        public bool XoaNhanVien(string maNV)
        {
            string sql = $"DELETE FROM NhanVien WHERE MaNV = '{maNV}'";
            thucthisql(sql);
            return true;
        }

        // Tìm kiếm nhân viên theo mã hoặc tên
        public DataTable TimKiemNhanVien(string maNV, string tenNV)
        {
            _con.Open();
            string sql = $"SELECT * FROM NhanVien WHERE MaNV LIKE '%{maNV}%' AND TenNV LIKE N'%{tenNV}%'";
            da = new SqlDataAdapter(sql, _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }
    }
}
