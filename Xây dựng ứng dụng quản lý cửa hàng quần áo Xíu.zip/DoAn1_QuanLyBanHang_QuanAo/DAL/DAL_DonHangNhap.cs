﻿using DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_DonHangNhap : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        // Lấy danh sách tất cả đơn hàng nhập
        public DataTable GetAllDonHangNhap()
        {
            _con.Open();
            string query = @"
                SELECT dhn.MaDHN, dhn.MaNCC, ncc.TenNCC, dhn.NgayNhap, dhn.TongTien
                FROM DonHangNhap dhn
                JOIN NhaCungCap ncc ON dhn.MaNCC = ncc.MaNCC";

            da = new SqlDataAdapter(query, _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Hàm thực thi câu lệnh SQL chung
        void thucthisql(string sql)
        {
            _con.Open();
            cmd = new SqlCommand(sql, _con);
            cmd.ExecuteNonQuery();
            _con.Close();
        }

        // Kiểm tra mã đơn hàng nhập trùng
        public int KiemTraMaTrung(string maDHN)
        {
            _con.Open();
            string sql = $"SELECT COUNT(*) FROM DonHangNhap WHERE MaDHN = '{maDHN.Trim()}'";
            cmd = new SqlCommand(sql, _con);
            int count = (int)cmd.ExecuteScalar();
            _con.Close();
            return count;
        }

        // Thêm đơn hàng nhập
        public bool ThemDonHangNhap(DTO_DonHangNhap dhn)
        {
            if (KiemTraMaTrung(dhn.MaDHN) > 0)
            {
                return false; // Mã đơn hàng đã tồn tại
            }
            else
            {
                string sql = $"INSERT INTO DonHangNhap (MaDHN, MaNCC, NgayNhap, TongTien) " +
                             $"VALUES ('{dhn.MaDHN}', '{dhn.MaNCC}', '{dhn.NgayNhap:yyyy-MM-dd}', {dhn.TongTien})";
                thucthisql(sql);
                return true;
            }
        }

        // Sửa đơn hàng nhập
        public bool SuaDonHangNhap(DTO_DonHangNhap dhn)
        {
            string sql = $"UPDATE DonHangNhap SET " +
                         $"MaNCC = '{dhn.MaNCC}', " +
                         $"NgayNhap = '{dhn.NgayNhap:yyyy-MM-dd}', " +
                         $"TongTien = {dhn.TongTien} " +
                         $"WHERE MaDHN = '{dhn.MaDHN}'";

            thucthisql(sql);
            return true;
        }

        // Xóa đơn hàng nhập
        public bool XoaDonHangNhap(string maDHN)
        {
            string sql = $"DELETE FROM DonHangNhap WHERE MaDHN = '{maDHN}'";
            thucthisql(sql);
            return true;
        }

        // Tìm kiếm đơn hàng nhập theo mã đơn hoặc mã nhà cung cấp
        public DataTable TimKiemDonHangNhap(string maDHN, string maNCC)
        {
            _con.Open();
            string sql = @"
                SELECT dhn.MaDHN, dhn.MaNCC, ncc.TenNCC, dhn.NgayNhap, dhn.TongTien
                FROM DonHangNhap dhn
                JOIN NhaCungCap ncc ON dhn.MaNCC = ncc.MaNCC
                WHERE dhn.MaDHN LIKE @maDHN AND dhn.MaNCC LIKE @maNCC";

            da = new SqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("@maDHN", "%" + maDHN + "%");
            da.SelectCommand.Parameters.AddWithValue("@maNCC", "%" + maNCC + "%");

            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }
    }
}
