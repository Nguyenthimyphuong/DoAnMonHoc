﻿using DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_ChiTietDonHangBan : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        // Lấy toàn bộ chi tiết đơn hàng bán
        public DataTable GetAllChiTietDonHangBan()
        {
            _con.Open();
            da = new SqlDataAdapter("SELECT * FROM ChiTietDonHangBan", _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Hàm thực thi câu lệnh SQL chung
        void thucthisql(string sql)
        {
            _con.Open();
            cmd = new SqlCommand(sql, _con);
            cmd.ExecuteNonQuery();
            _con.Close();
        }


        // Lấy chi tiết theo mã đơn hàng
        public DataTable GetChiTietTheoMaDHB(string maDHB)
        {
            _con.Open();
            string sql = $@"
                SELECT ct.*, sp.TenSP
                FROM ChiTietDonHangBan ct
                JOIN SanPham sp ON ct.MaSP = sp.MaSP
                WHERE ct.MaDHB = '{maDHB}'";
            da = new SqlDataAdapter(sql, _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Kiểm tra mã sản phẩm trong đơn hàng đã tồn tại hay chưa
        public int KiemTraTrung(string maDHB, string maSP)
        {
            _con.Open();
            string sql = $"SELECT COUNT(*) FROM ChiTietDonHangBan WHERE MaDHB = '{maDHB}' AND MaSP = '{maSP}'";
            cmd = new SqlCommand(sql, _con);
            int count = (int)cmd.ExecuteScalar();
            _con.Close();
            return count;
        }

        // Thêm chi tiết đơn hàng bán
        public bool ThemChiTiet(DTO_ChiTietDonHangBan ct)
        {
            if (KiemTraTrung(ct.MaDHB, ct.MaSP) > 0)
            {
                return false; // đã tồn tại sản phẩm trong đơn hàng
            }

            string sql = $"INSERT INTO ChiTietDonHangBan (MaDHB, MaSP, SoLuong, DonGia, ThanhTien) " +
                         $"VALUES ('{ct.MaDHB}', '{ct.MaSP}', {ct.SoLuong}, {ct.DonGia}, {ct.ThanhTien})";

            thucthisql(sql);

            return true;
        }

        // Sửa chi tiết đơn hàng bán
        public bool SuaChiTiet(DTO_ChiTietDonHangBan ct)
        {
            string sql = $"UPDATE ChiTietDonHangBan SET " +
                         $"SoLuong = {ct.SoLuong}, " +
                         $"DonGia = {ct.DonGia}, " +
                         $"ThanhTien = {ct.ThanhTien} " +
                         $"WHERE MaDHB = '{ct.MaDHB}' AND MaSP = '{ct.MaSP}'";

            thucthisql(sql);
            return true;
        }

        // Xóa chi tiết đơn hàng bán
        public bool XoaChiTiet(string maDHB, string maSP)
        {
            string sql = $"DELETE FROM ChiTietDonHangBan WHERE MaDHB = '{maDHB}' AND MaSP = '{maSP}'";

            thucthisql(sql);
            return true;
        }

        // Tính tổng tiền đơn hàng theo mã đơn
        public decimal TinhTongTienTheoMaDHB(string maDHB)
        {
            _con.Open();
            string sql = $"SELECT SUM(ThanhTien) FROM ChiTietDonHangBan WHERE MaDHB = '{maDHB}'";
            cmd = new SqlCommand(sql, _con);
            decimal tongTien = (decimal)cmd.ExecuteScalar();
            _con.Close();
            return tongTien;
        }
    }
}
