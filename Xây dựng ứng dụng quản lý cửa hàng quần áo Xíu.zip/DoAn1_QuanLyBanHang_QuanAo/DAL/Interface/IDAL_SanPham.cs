﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Interface
{
    public interface IDAL_SanPham
    {
        DataTable GetAllSanPham();
        bool ThemSanPham(DTO_SanPham sp);
        bool SuaSanPham(DTO_SanPham sp);
        bool XoaSanPham(string maSP);
        DataTable TimKiemSanPham(string maSP, string tenSP);
        decimal GetDonGiaBanSP(string maSP);
    }
}
