﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_BaoCaoDoanhThu : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        public DataTable GetDoanhThuTheoNgay(DateTime ngay)
        {
            cmd = new SqlCommand("SP_BaoCaoDoanhThu_Ngay", _con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Ngay", ngay.Date);

            da = new SqlDataAdapter(cmd);
            dt = new DataTable();

            _con.Open();
            da.Fill(dt);
            _con.Close();

            return dt;
        }

        public DataTable GetDoanhThuTheoThang(int thang, int nam)
        {
            cmd = new SqlCommand("SP_BaoCaoDoanhThu_Thang", _con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Thang", thang);
            cmd.Parameters.AddWithValue("@Nam", nam);

            da = new SqlDataAdapter(cmd);
            dt = new DataTable();

            _con.Open();
            da.Fill(dt);
            _con.Close();

            return dt;
        }

        public DataTable GetDoanhThuTheoNam(int nam)
        {
            cmd = new SqlCommand("SP_BaoCaoDoanhThu_Nam", _con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Nam", nam);

            da = new SqlDataAdapter(cmd);
            dt = new DataTable();

            _con.Open();
            da.Fill(dt);
            _con.Close();

            return dt;
        }
    }
}
