﻿using DTO;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL_ChiTietDonHangNhap : DBConnect
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        // Lấy toàn bộ chi tiết đơn hàng nhập
        public DataTable GetAllChiTietDonHangNhap()
        {
            _con.Open();
            da = new SqlDataAdapter("SELECT * FROM ChiTietDonHangNhap", _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Hàm thực thi câu lệnh SQL chung
        void thucthisql(string sql)
        {
            _con.Open();
            cmd = new SqlCommand(sql, _con);
            cmd.ExecuteNonQuery();
            _con.Close();
        }

        // Lấy chi tiết theo mã đơn hàng nhập
        public DataTable GetChiTietTheoMaDHN(string maDHN)
        {
            _con.Open();
            string sql = $@"
                SELECT ct.*, sp.TenSP
                FROM ChiTietDonHangNhap ct
                JOIN SanPham sp ON ct.MaSP = sp.MaSP
                WHERE ct.MaDHN = '{maDHN}'";
            da = new SqlDataAdapter(sql, _con);
            dt = new DataTable();
            da.Fill(dt);
            _con.Close();
            return dt;
        }

        // Kiểm tra mã sản phẩm trong đơn hàng nhập đã tồn tại hay chưa
        public int KiemTraTrung(string maDHN, string maSP)
        {
            _con.Open();
            string sql = $"SELECT COUNT(*) FROM ChiTietDonHangNhap WHERE MaDHN = '{maDHN}' AND MaSP = '{maSP}'";
            cmd = new SqlCommand(sql, _con);
            int count = (int)cmd.ExecuteScalar();
            _con.Close();
            return count;
        }

        // Thêm chi tiết đơn hàng nhập
        public bool ThemChiTiet(DTO_ChiTietDonHangNhap ct)
        {
            if (KiemTraTrung(ct.MaDHN, ct.MaSP) > 0)
            {
                return false; // đã tồn tại sản phẩm trong đơn hàng
            }

            string sql = $"INSERT INTO ChiTietDonHangNhap (MaDHN, MaSP, SoLuong, DonGia, ThanhTien) " +
                         $"VALUES ('{ct.MaDHN}', '{ct.MaSP}', {ct.SoLuong}, {ct.DonGia}, {ct.ThanhTien})";

            thucthisql(sql);
            return true;
        }

        // Sửa chi tiết đơn hàng nhập
        public bool SuaChiTiet(DTO_ChiTietDonHangNhap ct)
        {
            string sql = $"UPDATE ChiTietDonHangNhap SET " +
                         $"SoLuong = {ct.SoLuong}, " +
                         $"DonGia = {ct.DonGia}, " +
                         $"ThanhTien = {ct.ThanhTien} " +
                         $"WHERE MaDHN = '{ct.MaDHN}' AND MaSP = '{ct.MaSP}'";

            thucthisql(sql);
            return true;
        }

        // Xóa chi tiết đơn hàng nhập
        public bool XoaChiTiet(string maDHN, string maSP)
        {
            string sql = $"DELETE FROM ChiTietDonHangNhap WHERE MaDHN = '{maDHN}' AND MaSP = '{maSP}'";

            thucthisql(sql);
            return true;
        }

        // Tính tổng tiền đơn hàng nhập theo mã đơn
        public decimal TinhTongTienTheoMaDHN(string maDHN)
        {
            _con.Open();
            string sql = $"SELECT SUM(ThanhTien) FROM ChiTietDonHangNhap WHERE MaDHN = '{maDHN}'";
            cmd = new SqlCommand(sql, _con);
            object result = cmd.ExecuteScalar();
            decimal tongTien = result == DBNull.Value ? 0 : Convert.ToDecimal(result);
            _con.Close();
            return tongTien;
        }
    }
}
