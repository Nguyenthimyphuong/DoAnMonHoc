﻿namespace GUI
{
    partial class GUI_QLNhaCungCap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnThoat = new Button();
            btnSua = new Button();
            btnThem = new Button();
            btnMoi = new Button();
            groupBox1 = new GroupBox();
            txtSoDienThoai = new TextBox();
            label7 = new Label();
            txtTenNCC = new TextBox();
            label4 = new Label();
            txtMaNCC = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtDiaChi = new TextBox();
            dgvNhaCungCap = new DataGridView();
            btnTimKiem = new Button();
            txtTenNCCTimKiem = new TextBox();
            txtMaNCCTimKiem = new TextBox();
            label6 = new Label();
            label5 = new Label();
            btnXoa = new Button();
            groupBox2 = new GroupBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhaCungCap).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Microsoft Sans Serif", 12F);
            btnThoat.Location = new Point(728, 415);
            btnThoat.Margin = new Padding(3, 2, 3, 2);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(82, 29);
            btnThoat.TabIndex = 23;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click_1;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Microsoft Sans Serif", 12F);
            btnSua.Location = new Point(380, 415);
            btnSua.Margin = new Padding(3, 2, 3, 2);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(82, 29);
            btnSua.TabIndex = 21;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Microsoft Sans Serif", 12F);
            btnThem.Location = new Point(206, 415);
            btnThem.Margin = new Padding(3, 2, 3, 2);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(82, 29);
            btnThem.TabIndex = 20;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnMoi
            // 
            btnMoi.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoi.Location = new Point(32, 415);
            btnMoi.Margin = new Padding(3, 2, 3, 2);
            btnMoi.Name = "btnMoi";
            btnMoi.Size = new Size(82, 29);
            btnMoi.TabIndex = 19;
            btnMoi.Text = "Mới";
            btnMoi.UseVisualStyleBackColor = true;
            btnMoi.Click += btnMoi_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtSoDienThoai);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtTenNCC);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtMaNCC);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtDiaChi);
            groupBox1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(24, 7);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(784, 141);
            groupBox1.TabIndex = 16;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin nhà cung cấp";
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.Font = new Font("Microsoft Sans Serif", 12F);
            txtSoDienThoai.Location = new Point(538, 102);
            txtSoDienThoai.Margin = new Padding(3, 2, 3, 2);
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(230, 26);
            txtSoDienThoai.TabIndex = 8;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F);
            label7.Location = new Point(395, 106);
            label7.Name = "label7";
            label7.Size = new Size(102, 20);
            label7.TabIndex = 7;
            label7.Text = "Số điện thoại";
            // 
            // txtTenNCC
            // 
            txtTenNCC.Font = new Font("Microsoft Sans Serif", 12F);
            txtTenNCC.Location = new Point(538, 39);
            txtTenNCC.Margin = new Padding(3, 2, 3, 2);
            txtTenNCC.Name = "txtTenNCC";
            txtTenNCC.Size = new Size(230, 26);
            txtTenNCC.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F);
            label4.Location = new Point(12, 92);
            label4.Name = "label4";
            label4.Size = new Size(57, 20);
            label4.TabIndex = 3;
            label4.Text = "Địa chỉ";
            // 
            // txtMaNCC
            // 
            txtMaNCC.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaNCC.Location = new Point(128, 40);
            txtMaNCC.Margin = new Padding(3, 2, 3, 2);
            txtMaNCC.Name = "txtMaNCC";
            txtMaNCC.Size = new Size(230, 26);
            txtMaNCC.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F);
            label2.Location = new Point(12, 40);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 1;
            label2.Text = "Mã NCC *";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F);
            label3.Location = new Point(395, 43);
            label3.Name = "label3";
            label3.Size = new Size(83, 20);
            label3.TabIndex = 2;
            label3.Text = "Tên NCC *";
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Microsoft Sans Serif", 12F);
            txtDiaChi.Location = new Point(128, 78);
            txtDiaChi.Margin = new Padding(3, 2, 3, 2);
            txtDiaChi.Multiline = true;
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(230, 48);
            txtDiaChi.TabIndex = 5;
            // 
            // dgvNhaCungCap
            // 
            dgvNhaCungCap.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvNhaCungCap.Location = new Point(24, 174);
            dgvNhaCungCap.Margin = new Padding(3, 2, 3, 2);
            dgvNhaCungCap.Name = "dgvNhaCungCap";
            dgvNhaCungCap.RowHeadersWidth = 51;
            dgvNhaCungCap.Size = new Size(784, 206);
            dgvNhaCungCap.TabIndex = 18;
            dgvNhaCungCap.CellClick += dgvNhaCungCap_CellClick;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            btnTimKiem.Location = new Point(648, 30);
            btnTimKiem.Margin = new Padding(3, 2, 3, 2);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(136, 28);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtTenNCCTimKiem
            // 
            txtTenNCCTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtTenNCCTimKiem.Location = new Point(433, 30);
            txtTenNCCTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtTenNCCTimKiem.Name = "txtTenNCCTimKiem";
            txtTenNCCTimKiem.Size = new Size(197, 26);
            txtTenNCCTimKiem.TabIndex = 3;
            // 
            // txtMaNCCTimKiem
            // 
            txtMaNCCTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaNCCTimKiem.Location = new Point(132, 33);
            txtMaNCCTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaNCCTimKiem.Name = "txtMaNCCTimKiem";
            txtMaNCCTimKiem.Size = new Size(148, 26);
            txtMaNCCTimKiem.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F);
            label6.Location = new Point(293, 35);
            label6.Name = "label6";
            label6.Size = new Size(73, 20);
            label6.TabIndex = 1;
            label6.Text = "Tên NCC";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F);
            label5.Location = new Point(9, 35);
            label5.Name = "label5";
            label5.Size = new Size(68, 20);
            label5.TabIndex = 0;
            label5.Text = "Mã NCC";
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoa.Location = new Point(554, 415);
            btnXoa.Margin = new Padding(3, 2, 3, 2);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(82, 29);
            btnXoa.TabIndex = 22;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnTimKiem);
            groupBox2.Controls.Add(txtTenNCCTimKiem);
            groupBox2.Controls.Add(txtMaNCCTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(28, 473);
            groupBox2.Margin = new Padding(3, 2, 3, 2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 2, 3, 2);
            groupBox2.Size = new Size(789, 62);
            groupBox2.TabIndex = 17;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F);
            label1.Location = new Point(271, -109);
            label1.Name = "label1";
            label1.Size = new Size(145, 20);
            label1.TabIndex = 15;
            label1.Text = "Quản Lý Loại Hàng";
            // 
            // GUI_QLNhaCungCap
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(834, 582);
            Controls.Add(btnThoat);
            Controls.Add(btnSua);
            Controls.Add(btnThem);
            Controls.Add(btnMoi);
            Controls.Add(groupBox1);
            Controls.Add(dgvNhaCungCap);
            Controls.Add(btnXoa);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GUI_QLNhaCungCap";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GUI_QLNhaCungCap";
            Load += GUI_QLNhaCungCap_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhaCungCap).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnThoat;
        private Button btnSua;
        private Button btnThem;
        private Button btnMoi;
        private GroupBox groupBox1;
        private TextBox txtTenNCC;
        private Label label4;
        private TextBox txtMaNCC;
        private Label label2;
        private Label label3;
        private TextBox txtDiaChi;
        private DataGridView dgvNhaCungCap;
        private Button btnTimKiem;
        private TextBox txtTenNCCTimKiem;
        private TextBox txtMaNCCTimKiem;
        private Label label6;
        private Label label5;
        private Button btnXoa;
        private GroupBox groupBox2;
        private Label label1;
        private TextBox txtSoDienThoai;
        private Label label7;
    }
}