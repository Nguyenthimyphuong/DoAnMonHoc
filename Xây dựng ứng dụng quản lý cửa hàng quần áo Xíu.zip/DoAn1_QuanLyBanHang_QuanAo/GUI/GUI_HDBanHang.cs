﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace GUI
{
    public partial class GUI_HDBanHang : Form
    {
        BLL_DonHangBan bllDonHangBan = new BLL_DonHangBan();
        BLL_ChiTietDonHangBan bllChiTietDonHangBan = new BLL_ChiTietDonHangBan();
        BLL_KhachHang bllKhachHang = new BLL_KhachHang();
        BLL_SanPham bllSanPham = new BLL_SanPham();
        public GUI_HDBanHang()
        {
            InitializeComponent();
        }

        void LoadDataDonHangBan()
        {
            // Load comboBox KhachHang
            cboMaKH.DataSource = bllKhachHang.GetAllKhachHang();
            cboMaKH.DisplayMember = "MaKH";
            cboMaKH.ValueMember = "MaKH";
            cboMaKH.SelectedIndex = -1;

            // Load DataGridView
            dgvDonHangBan.DataSource = bllDonHangBan.GetAllDonHangBan();
            dgvDonHangBan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDonHangBan.Columns["MaDHB"].HeaderText = "Mã ĐHB";
            dgvDonHangBan.Columns["MaKH"].HeaderText = "Mã KH";
            dgvDonHangBan.Columns["TenKH"].HeaderText = "Tên KH";
            dgvDonHangBan.Columns["NgayBan"].HeaderText = "Ngày Bán";
            dgvDonHangBan.Columns["TongTien"].HeaderText = "Tổng Tiền";

            dgvDonHangBan.Columns["NgayBan"].DefaultCellStyle.Format = "dd/MM/yyyy"; // Định dạng ngày tháng năm
        }

        void LoadDataChiTietDonHangBan()
        {
            // Load comboBox SanPham
            cboMaSP.DataSource = bllSanPham.GetAllSanPham();
            cboMaSP.DisplayMember = "MaSP";
            cboMaSP.ValueMember = "MaSP";

            // Load dữ liệu chi tiết đơn hàng bán tương ứng
            DataTable dtChiTiet = bllChiTietDonHangBan.GetChiTietTheoMaDHB(txtMaDHBChiTiet.Text);

            // Thêm cột STT
            if (!dtChiTiet.Columns.Contains("STT"))
                dtChiTiet.Columns.Add("STT", typeof(int));

            // Gán số thứ tự
            for (int i = 0; i < dtChiTiet.Rows.Count; i++)
            {
                dtChiTiet.Rows[i]["STT"] = i + 1;
            }

            dgvChiTietDonHangBan.DataSource = dtChiTiet;

            // Tùy chỉnh hiển thị
            dgvChiTietDonHangBan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Đặt lại thứ tự cột
            dgvChiTietDonHangBan.Columns["STT"].DisplayIndex = 0;
            dgvChiTietDonHangBan.Columns["MaDHB"].DisplayIndex = 1;
            dgvChiTietDonHangBan.Columns["MaSP"].DisplayIndex = 2;
            dgvChiTietDonHangBan.Columns["TenSP"].DisplayIndex = 3;
            dgvChiTietDonHangBan.Columns["SoLuong"].DisplayIndex = 4;
            dgvChiTietDonHangBan.Columns["DonGia"].DisplayIndex = 5;
            dgvChiTietDonHangBan.Columns["ThanhTien"].DisplayIndex = 6;

            dgvChiTietDonHangBan.Columns["STT"].HeaderText = "STT";
            dgvChiTietDonHangBan.Columns["MaDHB"].HeaderText = "Mã ĐHB";
            dgvChiTietDonHangBan.Columns["MaSP"].HeaderText = "Mã SP";
            dgvChiTietDonHangBan.Columns["TenSP"].HeaderText = "Tên SP";
            dgvChiTietDonHangBan.Columns["SoLuong"].HeaderText = "Số lượng";
            dgvChiTietDonHangBan.Columns["DonGia"].HeaderText = "Đơn giá";
            dgvChiTietDonHangBan.Columns["ThanhTien"].HeaderText = "Thành tiền";

            dgvChiTietDonHangBan.Columns["MaCTDHB"].Visible = false;
            dgvChiTietDonHangBan.Columns["MaDHB"].Visible = false;
            dgvChiTietDonHangBan.Columns["STT"].Width = 50;
            dgvChiTietDonHangBan.Columns["MaSP"].Width = 50;
        }

        void TinhTongTien()
        {
            decimal tongTien = 0;
            foreach (DataGridViewRow row in dgvChiTietDonHangBan.Rows)
            {
                if (row.Cells["ThanhTien"].Value != null)
                {
                    tongTien += Convert.ToDecimal(row.Cells["ThanhTien"].Value);
                }
            }
            lblTongTien.Text = tongTien.ToString("N0") + " VNĐ"; // Định dạng tiền
        }

        void TinhThanhTien()
        {
            // Loại bỏ "VNĐ" và dấu phân tách hàng ngàn nếu có
            string donGiaText = lblDonGia.Text.Replace("VNĐ", "").Trim().Replace(",", "");
            if (decimal.TryParse(donGiaText, out decimal donGia))
            {
                int soLuong = (int)nudSoLuong.Value;
                decimal thanhTien = donGia * soLuong;
                lblThanhTien.Text = thanhTien.ToString("N0") + " VNĐ"; // Format tiền tệ
            }
            else
            {
                lblThanhTien.Text = "0 VNĐ";
            }
        }

        private void GUI_HDBanHang_Load(object sender, EventArgs e)
        {
            txtMaDHBChiTiet.Enabled = false; // Không cho phép nhập mã ĐHB chi tiết
            LoadDataDonHangBan();

            // Thiết lập giới hạn số lượng sản phẩm
            nudSoLuong.Minimum = 1;
            nudSoLuong.Maximum = 1000;
        }

        private void btnMoiDHB_Click(object sender, EventArgs e)
        {
            txtMaDHB.Enabled = true; // Cho phép nhập mã ĐHB mới
            txtMaDHB.Clear();
            cboMaKH.SelectedIndex = -1;
            dtpNgayBan.Value = DateTime.Now;
            lblTongTien.Text = "0 VNĐ";
            lblTenKhachHang.Text = "";
            txtMaDHBChiTiet.Clear();
            dgvChiTietDonHangBan.DataSource = null; // Xóa dữ liệu chi tiết đơn hàng bán

            txtMaDHB.Focus();
            LoadDataDonHangBan();
        }

        private void dgvDonHangBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                if (rowIndex < 0) return;

                // Lấy dữ liệu từ dòng đã chọn
                DataGridViewRow row = dgvDonHangBan.Rows[rowIndex];
                string maDHB = row.Cells["MaDHB"].Value.ToString();
                string maKH = row.Cells["MaKH"].Value.ToString();
                DateTime ngayBan = Convert.ToDateTime(row.Cells["NgayBan"].Value);
                decimal tongTien = Convert.ToDecimal(row.Cells["TongTien"].Value);

                // Cập nhật thông tin vào các điều khiển
                txtMaDHB.Text = maDHB;
                txtMaDHBChiTiet.Text = maDHB; // Cập nhật mã ĐHB chi tiết
                cboMaKH.SelectedValue = maKH;
                dtpNgayBan.Value = ngayBan;
                lblTongTien.Text = tongTien.ToString("N0") + " VNĐ"; // Định dạng tiền 

                // Load dữ liệu chi tiết đơn hàng bán
                LoadDataChiTietDonHangBan();
                txtMaDHB.Enabled = false; // Không cho phép sửa mã ĐHB

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnThemDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHB.Text.Trim();

                // Kiểm tra xem người dùng đã chọn khách hàng chưa
                if (cboMaKH.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn Mã khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string maKH = cboMaKH.SelectedValue.ToString();
                DateTime ngayBan = dtpNgayBan.Value;
                decimal tongTien;

                if (string.IsNullOrEmpty(maDHB) || string.IsNullOrEmpty(maKH))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ Mã ĐHB và Mã khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string tongTienText = lblTongTien.Text.Replace("VNĐ", "").Trim().Replace(",", "");

                if (!decimal.TryParse(tongTienText, out tongTien))
                {
                    MessageBox.Show("Tổng tiền không hợp lệ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_DonHangBan dhb = new DTO_DonHangBan(maDHB, maKH, ngayBan, tongTien);
                if (bllDonHangBan.ThemDonHangBan(dhb))
                {
                    MessageBox.Show("Thêm đơn hàng bán thành công");
                    LoadDataDonHangBan();
                }
                else
                {
                    MessageBox.Show("Mã ĐHB đã tồn tại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }

        }

        private void btnSuaDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHB.Text.Trim();

                // Kiểm tra xem người dùng đã chọn khách hàng chưa
                if (cboMaKH.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn Mã khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string maKH = cboMaKH.SelectedValue.ToString();
                DateTime ngayBan = dtpNgayBan.Value;

                string tongTienText = lblTongTien.Text.Replace("VNĐ", "").Trim().Replace(",", "");
                decimal tongTien = tongTienText == "" ? 0 : decimal.Parse(tongTienText);

                if (string.IsNullOrEmpty(maDHB))
                {
                    MessageBox.Show("Vui lòng chọn đơn hàng bán cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_DonHangBan dhb = new DTO_DonHangBan(maDHB, maKH, ngayBan, tongTien);

                if (bllDonHangBan.SuaDonHangBan(dhb))
                {
                    MessageBox.Show("Sửa đơn hàng bán thành công");
                    LoadDataDonHangBan();
                }
                else
                {
                    MessageBox.Show("Mã ĐHB không tồn tại");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }

        }

        private void btnXoaDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHB.Text.Trim();

                if (string.IsNullOrEmpty(maDHB))
                {
                    MessageBox.Show("Vui lòng chọn đơn hàng bán cần xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa đơn hàng bán này? Lưu ý: Tất cả các dữ liệu chi tiết liên quan sẽ bị xóa.",
                                      "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (bllDonHangBan.XoaDonHangBan(maDHB))
                    {
                        MessageBox.Show("Xóa đơn hàng bán thành công");
                        LoadDataDonHangBan();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy đơn hàng bán để xóa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInHoaDonDHB_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnXuatExcelDHB_Click(object sender, EventArgs e)
        {

        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string maDHB = txtMaDHBTimKiem.Text.Trim();
            string maKH = txtMaKHTimKiem.Text.Trim();
            if (string.IsNullOrEmpty(maDHB) && string.IsNullOrEmpty(maKH))
            {
                MessageBox.Show("Vui lòng nhập Mã ĐHB hoặc Mã KH để tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dt = bllDonHangBan.TimKiemDonHangBan(maDHB, maKH);
            dgvDonHangBan.DataSource = dt;
        }

        // Hàm xử lý sự kiện khi chọn một khách hàng trong comboBox
        // Hiển thị tên khách hàng tương ứng với mã khách hàng đã chọn
        private void cboMaKH_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMaKH.SelectedIndex >= 0 && cboMaKH.SelectedValue != null)
            {
                string maKH = cboMaKH.SelectedValue.ToString();
                DataTable dt = bllKhachHang.TimKiemKhachHang(maKH, "");

                if (dt.Rows.Count > 0)
                {
                    lblTenKhachHang.Text = dt.Rows[0]["TenKH"].ToString();
                }
                else
                {
                    lblTenKhachHang.Text = "";
                }
            }
            else
            {
                lblTenKhachHang.Text = "";
            }
        }

        private void dgvChiTietDonHangBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                if (rowIndex < 0) return;

                DataGridViewRow row = dgvChiTietDonHangBan.Rows[rowIndex];

                decimal donGia = Convert.ToDecimal(row.Cells["DonGia"].Value);
                decimal thanhTien = Convert.ToDecimal(row.Cells["ThanhTien"].Value);
                cboMaSP.SelectedValue = row.Cells["MaSP"].Value.ToString();
                nudSoLuong.Value = Convert.ToInt32(row.Cells["SoLuong"].Value);
                lblDonGia.Text = donGia.ToString("N0") + " VNĐ";
                lblThanhTien.Text = thanhTien.ToString("N0") + " VNĐ";

                cboMaSP.Enabled = false; // Không cho phép thay đổi mã sản phẩm
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        // Hàm xử lý sự kiện khi chọn một sản phẩm trong comboBox
        // Hiển thị tên sản phẩm tương ứng với mã sản phẩm đã chọn
        private void cboMaSP_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMaSP.SelectedIndex >= 0 && cboMaSP.SelectedValue != null)
            {
                string maSP = cboMaSP.SelectedValue.ToString();

                // Tìm kiếm sản phẩm theo mã
                DataTable dt = bllSanPham.TimKiemSanPham(maSP, "");

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    // Hiển thị tên sản phẩm
                    lblTenSanPham.Text = row["TenSP"].ToString();

                    // Hiển thị đơn giá
                    if (decimal.TryParse(row["DonGiaBan"].ToString(), out decimal donGia))
                    {
                        lblDonGia.Text = donGia.ToString("N0") + " VNĐ";
                        TinhThanhTien();
                    }
                    else
                    {
                        lblDonGia.Text = "0 VNĐ";
                        lblThanhTien.Text = "0 VNĐ";
                    }
                }
                else
                {
                    lblTenSanPham.Text = "";
                    lblDonGia.Text = "";
                    lblThanhTien.Text = "";
                }
            }
            else
            {
                lblTenSanPham.Text = "";
                lblDonGia.Text = "";
                lblThanhTien.Text = "";
            }
        }

        // Hàm xử lý sự kiện khi thay đổi số lượng sản phẩm
        // Tính toán thành tiền tương ứng với số lượng và đơn giá
        private void nudSoLuong_ValueChanged(object sender, EventArgs e)
        {
            TinhThanhTien();
        }

        private void btnMoiChiTietDHB_Click(object sender, EventArgs e)
        {
            //txtMaDHBChiTiet.Clear();
            cboMaSP.SelectedIndex = -1;
            lblTenSanPham.Text = "";
            nudSoLuong.Value = 1;
            lblDonGia.Text = "0 VNĐ";
            lblThanhTien.Text = "0 VNĐ";
            //dgvChiTietDonHangBan.DataSource = null;

            cboMaSP.Enabled = true; // Cho phép chọn sản phẩm mới
        }

        private void btnThemChiTietDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHBChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHB))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng bán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHBChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();
                int soLuong = (int)nudSoLuong.Value;

                // Lấy đơn giá từ sản phẩm
                decimal donGia = bllSanPham.GetDonGiaBanSP(maSP);
                decimal thanhTien = donGia * soLuong;

                DTO_ChiTietDonHangBan ct = new DTO_ChiTietDonHangBan(maDHB, maSP, soLuong, donGia, thanhTien);
                if (bllChiTietDonHangBan.ThemChiTietDonHangBan(ct))
                {
                    MessageBox.Show("Thêm chi tiết đơn hàng bán thành công");
                    LoadDataChiTietDonHangBan();
                    LoadDataDonHangBan();
                    TinhTongTien();
                }
                else
                {
                    MessageBox.Show("Sản phẩm đã tồn tại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnSuaChiTietDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHBChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHB))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng bán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHBChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();
                int soLuong = (int)nudSoLuong.Value;

                decimal donGia = bllSanPham.GetDonGiaBanSP(maSP);
                decimal thanhTien = donGia * soLuong;

                DTO_ChiTietDonHangBan ct = new DTO_ChiTietDonHangBan(maDHB, maSP, soLuong, donGia, thanhTien);
                if (bllChiTietDonHangBan.SuaChiTietDonHangBan(ct))
                {
                    MessageBox.Show("Sửa chi tiết đơn hàng bán thành công");
                    LoadDataChiTietDonHangBan();
                    LoadDataDonHangBan();
                    TinhTongTien();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy chi tiết để sửa");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnXoaChiTietDHB_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHB = txtMaDHBChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHB))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng bán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHBChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();

                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa chi tiết sản phẩm này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (bllChiTietDonHangBan.XoaChiTietDonHangBan(maDHB, maSP))
                    {
                        MessageBox.Show("Xóa chi tiết thành công");
                        LoadDataChiTietDonHangBan();
                        LoadDataDonHangBan();
                        TinhTongTien();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy chi tiết để xóa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font titleFont = new Font("Arial", 20, FontStyle.Bold);
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);
            Font textFont = new Font("Arial", 12);
            SolidBrush blueBrush = new SolidBrush(Color.Blue);
            SolidBrush blackBrush = new SolidBrush(Color.Black);

            int y = 50; // Vị trí bắt đầu y

            // 1. Tiêu đề:
            string title = "SHOP QUAN AO";


            SizeF titleSize = g.MeasureString(title, titleFont);
            g.DrawString(title, titleFont, blueBrush, (e.PageBounds.Width - titleSize.Width) / 2, y);
            y += 50;

            // 2. Mã hóa đơn và ngày
            g.DrawString("Mã hóa đơn: " + txtMaDHB.Text, textFont, blackBrush, 50, y);
            DateTime ngayBan = Convert.ToDateTime(dgvDonHangBan.CurrentRow.Cells["NgayBan"].Value);
            g.DrawString("Ngày: " + ngayBan.ToString("dd/MM/yyyy"), textFont, blackBrush, e.PageBounds.Width - 250, y);
            y += 40;


            // 3. Thông tin khách hàng
            g.DrawString("THÔNG TIN KHÁCH HÀNG", headerFont, blackBrush, 50, y);
            y += 30;

            string tenKH = lblTenKhachHang.Text;
            //string diaChi = bllKhachHang.GetDiaChiTheoMaKH(cboMaKH.SelectedValue.ToString());
            //string sdt = bllKhachHang.GetSDTTheoMaKH(cboMaKH.SelectedValue.ToString());

            g.DrawString("Tên khách hàng: " + tenKH, textFont, blackBrush, 70, y); y += 25;
            //g.DrawString("Địa chỉ: " + diaChi, textFont, blackBrush, 70, y); y += 25;
            //g.DrawString("SĐT: " + sdt, textFont, blackBrush, 70, y); y += 30;

            // 4. Vẽ bảng sản phẩm
            int startX = 50;
            int tableWidth = e.PageBounds.Width - 100;
            int[] colWidths = { 50, 250, 100, 100, 120 };
            string[] headers = { "STT", "Tên SP", "Đơn giá", "Số lượng", "Thành tiền" };

            int tableY = y;

            // Header bảng
            int colX = startX;
            for (int i = 0; i < headers.Length; i++)
            {
                g.DrawRectangle(Pens.Black, colX, tableY, colWidths[i], 30);
                g.DrawString(headers[i], headerFont, blackBrush, colX + 5, tableY + 5);
                colX += colWidths[i];
            }
            tableY += 30;

            // Dữ liệu sản phẩm
            int stt = 1;
            foreach (DataGridViewRow row in dgvChiTietDonHangBan.Rows)
            {
                if (row.IsNewRow) continue;

                string tenSP = row.Cells["TenSP"].Value?.ToString() ?? "";
                string donGia = string.Format("{0:N0}", row.Cells["DonGia"].Value);
                string soLuong = row.Cells["SoLuong"].Value?.ToString() ?? "";
                string thanhTien = string.Format("{0:N0}", row.Cells["ThanhTien"].Value);

                string[] rowData = {
                    stt.ToString(),
                    tenSP,
                    donGia,
                    soLuong,
                    thanhTien
                };

                colX = startX;
                for (int i = 0; i < rowData.Length; i++)
                {
                    g.DrawRectangle(Pens.Black, colX, tableY, colWidths[i], 30);
                    g.DrawString(rowData[i], textFont, blackBrush, colX + 5, tableY + 5);
                    colX += colWidths[i];
                }

                tableY += 30;
                stt++;
            }

            y = tableY + 20;

            // 5. Tổng tiền
            g.DrawString("Tổng tiền: " + lblTongTien.Text, headerFont, blackBrush, e.PageBounds.Width - 300, y);
            y += 50;

            // 6. Cảm ơn khách hàng
            g.DrawString("Cảm ơn quý khách đã mua hàng", textFont, blueBrush, (e.PageBounds.Width - 300) / 2, y);
        }
    }
}
