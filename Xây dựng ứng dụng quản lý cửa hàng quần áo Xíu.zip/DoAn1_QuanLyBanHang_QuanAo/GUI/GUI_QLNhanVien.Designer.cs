﻿namespace GUI
{
    partial class GUI_QLNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            errorProvider1 = new ErrorProvider(components);
            txtDienThoai = new TextBox();
            label8 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtDiaChi = new TextBox();
            btnTimKiem = new Button();
            txtTenNVTimKiem = new TextBox();
            txtMaNV = new TextBox();
            btnXoa = new Button();
            label7 = new Label();
            txtTenNV = new TextBox();
            btnThoat = new Button();
            label5 = new Label();
            btnSua = new Button();
            btnThem = new Button();
            btnMoi = new Button();
            groupBox1 = new GroupBox();
            dtpNgaySinh = new DateTimePicker();
            checkBoxGioiTinh = new CheckBox();
            label9 = new Label();
            label4 = new Label();
            txtMaNVTimKiem = new TextBox();
            label6 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            dgvNhanVien = new DataGridView();
            btnXuatExcel = new Button();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).BeginInit();
            SuspendLayout();
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // txtDienThoai
            // 
            txtDienThoai.Font = new Font("Microsoft Sans Serif", 12F);
            txtDienThoai.Location = new Point(128, 145);
            txtDienThoai.Margin = new Padding(3, 2, 3, 2);
            txtDienThoai.Name = "txtDienThoai";
            txtDienThoai.Size = new Size(230, 26);
            txtDienThoai.TabIndex = 10;
            txtDienThoai.KeyPress += txtDienThoai_KeyPress;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 12F);
            label8.Location = new Point(8, 148);
            label8.Name = "label8";
            label8.Size = new Size(81, 20);
            label8.TabIndex = 9;
            label8.Text = "Điện thoại";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F);
            label2.Location = new Point(12, 40);
            label2.Name = "label2";
            label2.Size = new Size(67, 20);
            label2.TabIndex = 1;
            label2.Text = "Mã NV *";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F);
            label3.Location = new Point(395, 43);
            label3.Name = "label3";
            label3.Size = new Size(118, 20);
            label3.TabIndex = 2;
            label3.Text = "Tên nhân viên *";
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Microsoft Sans Serif", 12F);
            txtDiaChi.Location = new Point(538, 121);
            txtDiaChi.Margin = new Padding(3, 2, 3, 2);
            txtDiaChi.Multiline = true;
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(230, 48);
            txtDiaChi.TabIndex = 5;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            btnTimKiem.Location = new Point(661, 30);
            btnTimKiem.Margin = new Padding(3, 2, 3, 2);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(123, 28);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtTenNVTimKiem
            // 
            txtTenNVTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtTenNVTimKiem.Location = new Point(448, 30);
            txtTenNVTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtTenNVTimKiem.Name = "txtTenNVTimKiem";
            txtTenNVTimKiem.Size = new Size(197, 26);
            txtTenNVTimKiem.TabIndex = 3;
            // 
            // txtMaNV
            // 
            txtMaNV.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaNV.Location = new Point(128, 40);
            txtMaNV.Margin = new Padding(3, 2, 3, 2);
            txtMaNV.Name = "txtMaNV";
            txtMaNV.Size = new Size(230, 26);
            txtMaNV.TabIndex = 4;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoa.Location = new Point(674, 455);
            btnXoa.Margin = new Padding(3, 2, 3, 2);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(82, 29);
            btnXoa.TabIndex = 40;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F);
            label7.Location = new Point(10, 97);
            label7.Name = "label7";
            label7.Size = new Size(77, 20);
            label7.TabIndex = 7;
            label7.Text = "Giới tính *";
            // 
            // txtTenNV
            // 
            txtTenNV.Font = new Font("Microsoft Sans Serif", 12F);
            txtTenNV.Location = new Point(538, 39);
            txtTenNV.Margin = new Padding(3, 2, 3, 2);
            txtTenNV.Name = "txtTenNV";
            txtTenNV.Size = new Size(230, 26);
            txtTenNV.TabIndex = 6;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Microsoft Sans Serif", 12F);
            btnThoat.Location = new Point(824, 455);
            btnThoat.Margin = new Padding(3, 2, 3, 2);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(82, 29);
            btnThoat.TabIndex = 41;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F);
            label5.Location = new Point(9, 35);
            label5.Name = "label5";
            label5.Size = new Size(57, 20);
            label5.TabIndex = 0;
            label5.Text = "Mã NV";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Microsoft Sans Serif", 12F);
            btnSua.Location = new Point(523, 455);
            btnSua.Margin = new Padding(3, 2, 3, 2);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(82, 29);
            btnSua.TabIndex = 39;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Microsoft Sans Serif", 12F);
            btnThem.Location = new Point(373, 455);
            btnThem.Margin = new Padding(3, 2, 3, 2);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(82, 29);
            btnThem.TabIndex = 38;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnMoi
            // 
            btnMoi.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoi.Location = new Point(222, 455);
            btnMoi.Margin = new Padding(3, 2, 3, 2);
            btnMoi.Name = "btnMoi";
            btnMoi.Size = new Size(82, 29);
            btnMoi.TabIndex = 37;
            btnMoi.Text = "Mới";
            btnMoi.UseVisualStyleBackColor = true;
            btnMoi.Click += btnMoi_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dtpNgaySinh);
            groupBox1.Controls.Add(checkBoxGioiTinh);
            groupBox1.Controls.Add(txtDienThoai);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(txtTenNV);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtMaNV);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtDiaChi);
            groupBox1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(84, 19);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(784, 180);
            groupBox1.TabIndex = 34;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin nhân viên";
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.Format = DateTimePickerFormat.Short;
            dtpNgaySinh.Location = new Point(538, 92);
            dtpNgaySinh.Margin = new Padding(3, 2, 3, 2);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.Size = new Size(230, 21);
            dtpNgaySinh.TabIndex = 12;
            // 
            // checkBoxGioiTinh
            // 
            checkBoxGioiTinh.AutoSize = true;
            checkBoxGioiTinh.Location = new Point(128, 96);
            checkBoxGioiTinh.Margin = new Padding(3, 2, 3, 2);
            checkBoxGioiTinh.Name = "checkBoxGioiTinh";
            checkBoxGioiTinh.Size = new Size(53, 19);
            checkBoxGioiTinh.TabIndex = 11;
            checkBoxGioiTinh.Text = "Nam";
            checkBoxGioiTinh.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 12F);
            label9.Location = new Point(395, 90);
            label9.Name = "label9";
            label9.Size = new Size(78, 20);
            label9.TabIndex = 7;
            label9.Text = "Ngày sinh";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F);
            label4.Location = new Point(395, 145);
            label4.Name = "label4";
            label4.Size = new Size(57, 20);
            label4.TabIndex = 3;
            label4.Text = "Địa chỉ";
            // 
            // txtMaNVTimKiem
            // 
            txtMaNVTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaNVTimKiem.Location = new Point(132, 33);
            txtMaNVTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaNVTimKiem.Name = "txtMaNVTimKiem";
            txtMaNVTimKiem.Size = new Size(148, 26);
            txtMaNVTimKiem.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F);
            label6.Location = new Point(293, 35);
            label6.Name = "label6";
            label6.Size = new Size(108, 20);
            label6.TabIndex = 1;
            label6.Text = "Tên nhân viên";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F);
            label1.Location = new Point(331, -97);
            label1.Name = "label1";
            label1.Size = new Size(145, 20);
            label1.TabIndex = 33;
            label1.Text = "Quản Lý Loại Hàng";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnTimKiem);
            groupBox2.Controls.Add(txtTenNVTimKiem);
            groupBox2.Controls.Add(txtMaNVTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(88, 514);
            groupBox2.Margin = new Padding(3, 2, 3, 2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 2, 3, 2);
            groupBox2.Size = new Size(789, 62);
            groupBox2.TabIndex = 35;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // dgvNhanVien
            // 
            dgvNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvNhanVien.Location = new Point(84, 227);
            dgvNhanVien.Margin = new Padding(3, 2, 3, 2);
            dgvNhanVien.Name = "dgvNhanVien";
            dgvNhanVien.RowHeadersWidth = 51;
            dgvNhanVien.Size = new Size(784, 206);
            dgvNhanVien.TabIndex = 36;
            dgvNhanVien.CellClick += dgvNhanVien_CellClick;
            // 
            // btnXuatExcel
            // 
            btnXuatExcel.Font = new Font("Microsoft Sans Serif", 12F);
            btnXuatExcel.Location = new Point(51, 455);
            btnXuatExcel.Margin = new Padding(3, 2, 3, 2);
            btnXuatExcel.Name = "btnXuatExcel";
            btnXuatExcel.Size = new Size(103, 29);
            btnXuatExcel.TabIndex = 42;
            btnXuatExcel.Text = "Xuất Excel";
            btnXuatExcel.UseVisualStyleBackColor = true;
            btnXuatExcel.Click += btnXuatExcel_Click;
            // 
            // GUI_QLNhanVien
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(961, 645);
            Controls.Add(btnXuatExcel);
            Controls.Add(btnXoa);
            Controls.Add(btnThoat);
            Controls.Add(btnSua);
            Controls.Add(btnThem);
            Controls.Add(btnMoi);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(dgvNhanVien);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GUI_QLNhanVien";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GUI_QLNhanVien";
            Load += GUI_QLNhanVien_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ErrorProvider errorProvider1;
        private Button btnXoa;
        private Button btnThoat;
        private Button btnSua;
        private Button btnThem;
        private Button btnMoi;
        private GroupBox groupBox1;
        private TextBox txtDienThoai;
        private Label label8;
        private Label label7;
        private TextBox txtTenNV;
        private Label label4;
        private TextBox txtMaNV;
        private Label label2;
        private Label label3;
        private TextBox txtDiaChi;
        private Label label1;
        private GroupBox groupBox2;
        private Button btnTimKiem;
        private TextBox txtTenNVTimKiem;
        private TextBox txtMaNVTimKiem;
        private Label label6;
        private Label label5;
        private DataGridView dgvNhanVien;
        private Button btnXuatExcel;
        private DateTimePicker dtpNgaySinh;
        private CheckBox checkBoxGioiTinh;
        private Label label9;
    }
}