﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class MDI_TrangChu : Form
    {
        private Image originalBackgroundImage;

        public MDI_TrangChu()
        {
            InitializeComponent();
        }

        public void PhanQuyen()
        {
            if (Program.code == 0)
            {
                quảnLýNhânViênToolStripMenuItem.Enabled = false;
                báoCáoDoanhThuToolStripMenuItem.Enabled = false;
                đổiMậtKhẩuToolStripMenuItem.Enabled = false;
            }
            else
            {
                quảnLýNhânViênToolStripMenuItem.Enabled = true;
                báoCáoDoanhThuToolStripMenuItem.Enabled = true;
                đổiMậtKhẩuToolStripMenuItem.Enabled = true;
            }
        }

        private void MDI_TrangChu_Load(object sender, EventArgs e)
        {
            PhanQuyen();
            this.StartPosition = FormStartPosition.CenterScreen;

            // Gán quyền
            lblQuyen.Text = (Program.code == 0) ? "Nhân viên" : "Admin";

            try
            {
                string imagePath = @"D:\download\Xây dựng ứng dụng quản lý cửa hàng quần áo Xíu\DoAn1_QuanLyBanHang_QuanAo\GUI\Assets\quanaobg.jpeg";
                originalBackgroundImage = Image.FromFile(imagePath);
            }
            catch
            {
                MessageBox.Show("Không tìm thấy ảnh nền!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            CenterGroupBox();
            ResizeBackgroundImage();
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_DoiMatKhau a = new GUI_DoiMatKhau();
            a.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            GUI_DangNhap a = new GUI_DangNhap();
            a.ShowDialog();
        }

        private void quảnLýLoạiHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_QLLoaiHang a = new GUI_QLLoaiHang();
            a.ShowDialog();
        }

        private void quảnLýNhàCungCấpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_QLNhaCungCap a = new GUI_QLNhaCungCap();
            a.ShowDialog();
        }

        private void quảnLýKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_QLKhachHang a = new GUI_QLKhachHang();
            a.ShowDialog();
        }

        private void quảnLýSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_QLSanPham a = new GUI_QLSanPham();
            a.ShowDialog();
        }

        private void MDI_TrangChu_Resize(object sender, EventArgs e)
        {
            CenterGroupBox();
            ResizeBackgroundImage();

        }
        private void CenterGroupBox()
        {
            if (groupBox1 != null)
            {
                groupBox1.Left = (this.ClientSize.Width - groupBox1.Width) / 2;
                groupBox1.Top = (this.ClientSize.Height - groupBox1.Height) / 2;
            }
        }

        private void ResizeBackgroundImage()
        {
            if (originalBackgroundImage != null)
            {
                Bitmap bitmap = new Bitmap(originalBackgroundImage, this.ClientSize.Width, this.ClientSize.Height);
                this.BackgroundImage = bitmap;
                this.BackgroundImageLayout = ImageLayout.None;
            }
        }

        private void quảnLýNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_QLNhanVien a = new GUI_QLNhanVien();
            a.ShowDialog();
        }

        private void hóaĐơnBánHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_HDBanHang a = new GUI_HDBanHang();
            a.ShowDialog();
        }

        private void báoCáoDoanhThuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_BaoCaoDoanhThu a = new GUI_BaoCaoDoanhThu();
            a.ShowDialog();
        }

        private void hóaĐơnNhậpHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GUI_HDNhapHang a = new GUI_HDNhapHang();
            a.ShowDialog();
        }
    }
}
