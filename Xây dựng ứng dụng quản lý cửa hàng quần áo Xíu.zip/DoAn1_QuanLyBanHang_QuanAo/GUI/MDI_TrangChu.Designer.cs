﻿namespace GUI
{
    partial class MDI_TrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDI_TrangChu));
            menuStrip1 = new MenuStrip();
            quảnLýToolStripMenuItem = new ToolStripMenuItem();
            quảnLýLoạiHàngToolStripMenuItem = new ToolStripMenuItem();
            quảnLýNhàCungCấpToolStripMenuItem = new ToolStripMenuItem();
            quảnLýKháchHàngToolStripMenuItem = new ToolStripMenuItem();
            quảnLýSảnPhẩmToolStripMenuItem = new ToolStripMenuItem();
            quảnLýNhânViênToolStripMenuItem = new ToolStripMenuItem();
            hóaĐơnToolStripMenuItem = new ToolStripMenuItem();
            hóaĐơnNhậpHàngToolStripMenuItem = new ToolStripMenuItem();
            hóaĐơnBánHàngToolStripMenuItem = new ToolStripMenuItem();
            báoCáoThốngKêToolStripMenuItem = new ToolStripMenuItem();
            báoCáoDoanhThuToolStripMenuItem = new ToolStripMenuItem();
            quảnTrịHệThốngToolStripMenuItem = new ToolStripMenuItem();
            đổiMậtKhẩuToolStripMenuItem = new ToolStripMenuItem();
            đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
            groupBox1 = new GroupBox();
            lblQuyen = new Label();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Microsoft Sans Serif", 12F);
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { quảnLýToolStripMenuItem, hóaĐơnToolStripMenuItem, báoCáoThốngKêToolStripMenuItem, quảnTrịHệThốngToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1137, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýToolStripMenuItem
            // 
            quảnLýToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { quảnLýLoạiHàngToolStripMenuItem, quảnLýNhàCungCấpToolStripMenuItem, quảnLýKháchHàngToolStripMenuItem, quảnLýSảnPhẩmToolStripMenuItem, quảnLýNhânViênToolStripMenuItem });
            quảnLýToolStripMenuItem.Font = new Font("Microsoft Sans Serif", 12F);
            quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            quảnLýToolStripMenuItem.Size = new Size(221, 29);
            quảnLýToolStripMenuItem.Text = "Quản lý các danh mục";
            // 
            // quảnLýLoạiHàngToolStripMenuItem
            // 
            quảnLýLoạiHàngToolStripMenuItem.Name = "quảnLýLoạiHàngToolStripMenuItem";
            quảnLýLoạiHàngToolStripMenuItem.Size = new Size(289, 30);
            quảnLýLoạiHàngToolStripMenuItem.Text = "Quản lý loại hàng";
            quảnLýLoạiHàngToolStripMenuItem.Click += quảnLýLoạiHàngToolStripMenuItem_Click;
            // 
            // quảnLýNhàCungCấpToolStripMenuItem
            // 
            quảnLýNhàCungCấpToolStripMenuItem.Name = "quảnLýNhàCungCấpToolStripMenuItem";
            quảnLýNhàCungCấpToolStripMenuItem.Size = new Size(289, 30);
            quảnLýNhàCungCấpToolStripMenuItem.Text = "Quản lý nhà cung cấp";
            quảnLýNhàCungCấpToolStripMenuItem.Click += quảnLýNhàCungCấpToolStripMenuItem_Click;
            // 
            // quảnLýKháchHàngToolStripMenuItem
            // 
            quảnLýKháchHàngToolStripMenuItem.Name = "quảnLýKháchHàngToolStripMenuItem";
            quảnLýKháchHàngToolStripMenuItem.Size = new Size(289, 30);
            quảnLýKháchHàngToolStripMenuItem.Text = "Quản lý khách hàng";
            quảnLýKháchHàngToolStripMenuItem.Click += quảnLýKháchHàngToolStripMenuItem_Click;
            // 
            // quảnLýSảnPhẩmToolStripMenuItem
            // 
            quảnLýSảnPhẩmToolStripMenuItem.Name = "quảnLýSảnPhẩmToolStripMenuItem";
            quảnLýSảnPhẩmToolStripMenuItem.Size = new Size(289, 30);
            quảnLýSảnPhẩmToolStripMenuItem.Text = "Quản lý sản phẩm";
            quảnLýSảnPhẩmToolStripMenuItem.Click += quảnLýSảnPhẩmToolStripMenuItem_Click;
            // 
            // quảnLýNhânViênToolStripMenuItem
            // 
            quảnLýNhânViênToolStripMenuItem.Name = "quảnLýNhânViênToolStripMenuItem";
            quảnLýNhânViênToolStripMenuItem.Size = new Size(289, 30);
            quảnLýNhânViênToolStripMenuItem.Text = "Quản lý nhân viên";
            quảnLýNhânViênToolStripMenuItem.Click += quảnLýNhânViênToolStripMenuItem_Click;
            // 
            // hóaĐơnToolStripMenuItem
            // 
            hóaĐơnToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { hóaĐơnNhậpHàngToolStripMenuItem, hóaĐơnBánHàngToolStripMenuItem });
            hóaĐơnToolStripMenuItem.Name = "hóaĐơnToolStripMenuItem";
            hóaĐơnToolStripMenuItem.Size = new Size(100, 29);
            hóaĐơnToolStripMenuItem.Text = "Hóa đơn";
            // 
            // hóaĐơnNhậpHàngToolStripMenuItem
            // 
            hóaĐơnNhậpHàngToolStripMenuItem.Name = "hóaĐơnNhậpHàngToolStripMenuItem";
            hóaĐơnNhậpHàngToolStripMenuItem.Size = new Size(270, 30);
            hóaĐơnNhậpHàngToolStripMenuItem.Text = "Hóa đơn nhập hàng";
            hóaĐơnNhậpHàngToolStripMenuItem.Click += hóaĐơnNhậpHàngToolStripMenuItem_Click;
            // 
            // hóaĐơnBánHàngToolStripMenuItem
            // 
            hóaĐơnBánHàngToolStripMenuItem.Name = "hóaĐơnBánHàngToolStripMenuItem";
            hóaĐơnBánHàngToolStripMenuItem.Size = new Size(270, 30);
            hóaĐơnBánHàngToolStripMenuItem.Text = "Hóa đơn bán hàng";
            hóaĐơnBánHàngToolStripMenuItem.Click += hóaĐơnBánHàngToolStripMenuItem_Click;
            // 
            // báoCáoThốngKêToolStripMenuItem
            // 
            báoCáoThốngKêToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { báoCáoDoanhThuToolStripMenuItem });
            báoCáoThốngKêToolStripMenuItem.Font = new Font("Microsoft Sans Serif", 12F);
            báoCáoThốngKêToolStripMenuItem.Name = "báoCáoThốngKêToolStripMenuItem";
            báoCáoThốngKêToolStripMenuItem.Size = new Size(178, 29);
            báoCáoThốngKêToolStripMenuItem.Text = "Báo cáo thống kê";
            // 
            // báoCáoDoanhThuToolStripMenuItem
            // 
            báoCáoDoanhThuToolStripMenuItem.Name = "báoCáoDoanhThuToolStripMenuItem";
            báoCáoDoanhThuToolStripMenuItem.Size = new Size(262, 30);
            báoCáoDoanhThuToolStripMenuItem.Text = "Báo cáo doanh thu";
            báoCáoDoanhThuToolStripMenuItem.Click += báoCáoDoanhThuToolStripMenuItem_Click;
            // 
            // quảnTrịHệThốngToolStripMenuItem
            // 
            quảnTrịHệThốngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { đổiMậtKhẩuToolStripMenuItem, đăngXuấtToolStripMenuItem });
            quảnTrịHệThốngToolStripMenuItem.Font = new Font("Microsoft Sans Serif", 12F);
            quảnTrịHệThốngToolStripMenuItem.Name = "quảnTrịHệThốngToolStripMenuItem";
            quảnTrịHệThốngToolStripMenuItem.Size = new Size(176, 29);
            quảnTrịHệThốngToolStripMenuItem.Text = "Quản trị hệ thống";
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            đổiMậtKhẩuToolStripMenuItem.Font = new Font("Microsoft Sans Serif", 12F);
            đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            đổiMậtKhẩuToolStripMenuItem.Size = new Size(212, 30);
            đổiMậtKhẩuToolStripMenuItem.Text = "Đổi mật khẩu";
            đổiMậtKhẩuToolStripMenuItem.Click += đổiMậtKhẩuToolStripMenuItem_Click;
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Font = new Font("Microsoft Sans Serif", 12F);
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.Size = new Size(212, 30);
            đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(lblQuyen);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(0, 219);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1137, 164);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // lblQuyen
            // 
            lblQuyen.AutoSize = true;
            lblQuyen.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblQuyen.Location = new Point(949, 66);
            lblQuyen.Name = "lblQuyen";
            lblQuyen.Size = new Size(90, 25);
            lblQuyen.TabIndex = 1;
            lblQuyen.Text = "lblQuyen";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(261, 66);
            label1.Name = "label1";
            label1.Size = new Size(614, 32);
            label1.TabIndex = 0;
            label1.Text = "HỆ THỐNG QUẢN LÝ CỬA HÀNG QUẦN ÁO";
            // 
            // MDI_TrangChu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1137, 603);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "MDI_TrangChu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MDI_TrangChu";
            Load += MDI_TrangChu_Load;
            Resize += MDI_TrangChu_Resize;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem quảnLýToolStripMenuItem;
        private ToolStripMenuItem báoCáoThốngKêToolStripMenuItem;
        private ToolStripMenuItem quảnTrịHệThốngToolStripMenuItem;
        private ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private ToolStripMenuItem quảnLýLoạiHàngToolStripMenuItem;
        private ToolStripMenuItem quảnLýNhàCungCấpToolStripMenuItem;
        private ToolStripMenuItem quảnLýKháchHàngToolStripMenuItem;
        private ToolStripMenuItem quảnLýSảnPhẩmToolStripMenuItem;
        private GroupBox groupBox1;
        private Label lblQuyen;
        private Label label1;
        private ToolStripMenuItem quảnLýNhânViênToolStripMenuItem;
        private ToolStripMenuItem hóaĐơnToolStripMenuItem;
        private ToolStripMenuItem hóaĐơnNhậpHàngToolStripMenuItem;
        private ToolStripMenuItem hóaĐơnBánHàngToolStripMenuItem;
        private ToolStripMenuItem báoCáoDoanhThuToolStripMenuItem;
    }
}