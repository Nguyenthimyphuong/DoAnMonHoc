﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class GUI_QLNhanVien : Form
    {
        BLL_NhanVien bllNhanVien = new BLL_NhanVien();
        public GUI_QLNhanVien()
        {
            InitializeComponent();
        }

        // Load dữ liệu lên DataGridView
        void LoadDgv()
        {
            DataTable dt = bllNhanVien.GetAllNhanVien();
            dt.Columns.Add("GioiTinhText", typeof(string));

            foreach (DataRow row in dt.Rows)
            {
                row["GioiTinhText"] = (Convert.ToBoolean(row["GioiTinh"]) ? "Nam" : "Nữ");
            }

            dgvNhanVien.DataSource = dt;
            dgvNhanVien.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvNhanVien.Columns["MaNV"].HeaderText = "Mã NV";
            dgvNhanVien.Columns["TenNV"].HeaderText = "Tên NV";
            dgvNhanVien.Columns["GioiTinhText"].HeaderText = "Giới tính";
            dgvNhanVien.Columns["NgaySinh"].HeaderText = "Ngày sinh";
            dgvNhanVien.Columns["DiaChi"].HeaderText = "Địa chỉ";
            dgvNhanVien.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
            dgvNhanVien.Columns["GioiTinh"].Visible = false;

            dgvNhanVien.Columns["MaNV"].DisplayIndex = 0;
            dgvNhanVien.Columns["TenNV"].DisplayIndex = 1;
            dgvNhanVien.Columns["GioiTinhText"].DisplayIndex = 2;
            dgvNhanVien.Columns["NgaySinh"].DisplayIndex = 3;
            dgvNhanVien.Columns["DiaChi"].DisplayIndex = 4;
            dgvNhanVien.Columns["SoDienThoai"].DisplayIndex = 5;
        }

        private void GUI_QLNhanVien_Load(object sender, EventArgs e)
        {
            LoadDgv();
        }

        void ChanSua()
        {
            txtMaNV.Enabled = false;
        }

        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int hang = e.RowIndex;
                if (hang >= 0)
                {
                    txtMaNV.Text = dgvNhanVien.Rows[hang].Cells["MaNV"].Value.ToString();
                    txtTenNV.Text = dgvNhanVien.Rows[hang].Cells["TenNV"].Value.ToString();
                    checkBoxGioiTinh.Checked = Convert.ToBoolean(dgvNhanVien.Rows[hang].Cells["GioiTinh"].Value);
                    dtpNgaySinh.Value = Convert.ToDateTime(dgvNhanVien.Rows[hang].Cells["NgaySinh"].Value);
                    txtDiaChi.Text = dgvNhanVien.Rows[hang].Cells["DiaChi"].Value.ToString();
                    txtDienThoai.Text = dgvNhanVien.Rows[hang].Cells["SoDienThoai"].Value.ToString();
                    ChanSua();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            // Khởi tạo đối tượng SaveFileDialog
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            // Thiết lập các thuộc tính cho hộp thoại lưu file
            saveFileDialog1.Filter = "Excel files (*.xlsx)|*.xlsx";
            saveFileDialog1.FilterIndex = 0;
            saveFileDialog1.RestoreDirectory = true;

            // Hiển thị hộp thoại lưu file
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Khởi tạo đối tượng Excel
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel.Worksheet sheet = null;
                excel.Visible = false;
                sheet = workbook.Sheets["Sheet1"];
                sheet = workbook.ActiveSheet;

                // Gán giá trị và định dạng cho ô đầu tiên
                Microsoft.Office.Interop.Excel.Range headerRange = sheet.Cells[1, 1];
                headerRange.Value = "Danh sách nhân viên";
                headerRange.Font.Bold = true;
                headerRange.Font.Size = 20;

                // Gán tên cột vào dòng thứ hai
                for (int j = 0; j < dgvNhanVien.Columns.Count; j++)
                {
                    sheet.Cells[2, j + 1] = dgvNhanVien.Columns[j].HeaderText;
                }

                // Đổ dữ liệu từ DataGridView vào Excel
                for (int i = 0; i < dgvNhanVien.Rows.Count; i++)
                {
                    DataGridViewRow row = dgvNhanVien.Rows[i];
                    for (int j = 0; j < row.Cells.Count; j++)
                    {
                        sheet.Cells[i + 3, j + 1] = row.Cells[j].Value?.ToString() ?? "";
                    }
                }

                // Lưu file Excel
                workbook.SaveAs(saveFileDialog1.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                workbook.Close(true, Type.Missing, Type.Missing);
                excel.Quit();

                // Hiển thị thông báo khi xuất excel thành công
                MessageBox.Show("Xuất excel thành công!");
            }
        }

        private void btnMoi_Click(object sender, EventArgs e)
        {
            txtMaNV.Enabled = true;
            txtMaNVTimKiem.Text = "";
            txtTenNVTimKiem.Text = "";
            errorProvider1.Clear();
            foreach (System.Windows.Forms.Control ctl in groupBox1.Controls)
            {
                if (ctl is TextBox)
                {
                    ctl.Text = "";
                }
            }
            txtMaNV.Focus();
            LoadDgv();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string maNV = txtMaNV.Text.Trim();
                string tenNV = txtTenNV.Text.Trim();
                bool gioiTinh = checkBoxGioiTinh.Checked;
                DateTime ngaySinh = DateTime.Parse(dtpNgaySinh.Value.ToString("yyyy-MM-dd"));
                string diaChi = txtDiaChi.Text.Trim();
                string soDienThoai = txtDienThoai.Text.Trim();

                if (string.IsNullOrEmpty(maNV) || string.IsNullOrEmpty(tenNV))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin trước khi thêm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_NhanVien nhanVien = new DTO_NhanVien(maNV, tenNV, gioiTinh, ngaySinh, diaChi, soDienThoai);

                if (bllNhanVien.ThemNhanVien(nhanVien))
                {
                    MessageBox.Show("Thêm nhân viên thành công");
                    LoadDgv();
                }
                else
                {
                    MessageBox.Show("Mã nhân viên đã tồn tại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                string maNV = txtMaNV.Text.Trim();
                string tenNV = txtTenNV.Text.Trim();
                bool gioiTinh = checkBoxGioiTinh.Checked;
                DateTime ngaySinh = dtpNgaySinh.Value;
                string diaChi = txtDiaChi.Text.Trim();
                string soDienThoai = txtDienThoai.Text.Trim();

                if (string.IsNullOrEmpty(maNV))
                {
                    MessageBox.Show("Vui lòng chọn nhân viên cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_NhanVien nhanVien = new DTO_NhanVien(maNV, tenNV, gioiTinh, ngaySinh, diaChi, soDienThoai);
                if (bllNhanVien.SuaNhanVien(nhanVien))
                {
                    MessageBox.Show("Sửa nhân viên thành công");
                    LoadDgv();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy nhân viên để sửa");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string maNV = txtMaNV.Text.Trim();

                if (string.IsNullOrEmpty(maNV))
                {
                    MessageBox.Show("Vui lòng chọn nhân viên cần xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show("Bạn có chắc muốn xóa nhân viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (bllNhanVien.XoaNhanVien(maNV))
                    {
                        MessageBox.Show("Xóa nhân viên thành công");
                        LoadDgv();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy nhân viên để xóa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc muốn thoát?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string maNV = txtMaNVTimKiem.Text.Trim();
            string tenNV = txtTenNVTimKiem.Text.Trim();
            if (string.IsNullOrEmpty(maNV) && string.IsNullOrEmpty(tenNV))
            {
                MessageBox.Show("Vui lòng nhập Mã nhân viên hoặc Tên nhân viên để tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dt = bllNhanVien.TimKiemNhanVien(maNV, tenNV);
            dgvNhanVien.DataSource = dt;
        }

        private void txtDienThoai_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Chặn nhập ký tự không phải số
                this.errorProvider1.SetError(txtDienThoai, "Số điện thoại chỉ được nhập số");
            }
            else this.errorProvider1.Clear();
        }
    }
}
