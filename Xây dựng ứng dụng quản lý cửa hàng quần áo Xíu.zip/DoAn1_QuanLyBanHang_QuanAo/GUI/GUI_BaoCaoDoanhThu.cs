﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace GUI
{
    public partial class GUI_BaoCaoDoanhThu : Form
    {
        private BLL_BaoCaoDoanhThu baoCaoBLL = new BLL_BaoCaoDoanhThu();
        public GUI_BaoCaoDoanhThu()
        {
            InitializeComponent();
        }

        private void GUI_BaoCaoDoanhThu_Load(object sender, EventArgs e)
        {
            cboKieuThongKe.Items.AddRange(new string[] { "Ngày", "Tháng", "Năm" });
            cboKieuThongKe.SelectedIndex = 0;
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            string kieuThongKe = cboKieuThongKe.SelectedItem.ToString();
            DateTime selectedDate = dtpNgay.Value;
            DataTable dt = new DataTable();

            if (kieuThongKe == "Ngày")
            {
                dt = baoCaoBLL.LayDoanhThuTheoNgay(selectedDate.Date);
            }
            else if (kieuThongKe == "Tháng")
            {
                dt = baoCaoBLL.LayDoanhThuTheoThang(selectedDate.Month, selectedDate.Year);
            }
            else if (kieuThongKe == "Năm")
            {
                dt = baoCaoBLL.LayDoanhThuTheoNam(selectedDate.Year);
            }

            dgvKetQua.DataSource = dt;

            // Tính tổng doanh thu
            decimal tong = baoCaoBLL.TinhTongDoanhThu(dt);
            lblTongDoanhThu.Text = $"Tổng doanh thu: {tong:N0} VNĐ";
        }
    }
}
