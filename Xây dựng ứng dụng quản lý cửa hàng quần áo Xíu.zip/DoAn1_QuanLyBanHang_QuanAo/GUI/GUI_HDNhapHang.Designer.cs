﻿namespace GUI
{
    partial class GUI_HDNhapHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GUI_HDNhapHang));
            lblThanhTien = new Label();
            btnXoaChiTietDHN = new Button();
            groupBox3 = new GroupBox();
            btnTimKiem = new Button();
            txtMaNCCTimKiem = new TextBox();
            txtMaDHNTimKiem = new TextBox();
            maKHTimKiem = new Label();
            maDHBTimKiem = new Label();
            btnSuaChiTietDHN = new Button();
            btnThemChiTietDHN = new Button();
            btnMoiChiTietDHN = new Button();
            label13 = new Label();
            btnXuatExcelDHN = new Button();
            btnXoaDHN = new Button();
            lblTongTien = new Label();
            lblTenNCC = new Label();
            btnInHoaDonDHN = new Button();
            btnSuaDHN = new Button();
            label6 = new Label();
            btnThemDHN = new Button();
            dgvDonHangNhap = new DataGridView();
            label5 = new Label();
            btnMoiDHN = new Button();
            dtpNgayNhap = new DateTimePicker();
            cboMaNCC = new ComboBox();
            txtMaDHN = new TextBox();
            label12 = new Label();
            label11 = new Label();
            cboMaSP = new ComboBox();
            label10 = new Label();
            label9 = new Label();
            dgvChiTietDonHangNhap = new DataGridView();
            printPreviewDialog1 = new PrintPreviewDialog();
            label4 = new Label();
            lblTenSanPham = new Label();
            label15 = new Label();
            groupBoxChiTietDHB = new GroupBox();
            txtDonGia = new TextBox();
            nudSoLuong = new NumericUpDown();
            txtMaDHNChiTiet = new TextBox();
            label3 = new Label();
            label2 = new Label();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            groupBoxDHB = new GroupBox();
            label1 = new Label();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDonHangNhap).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonHangNhap).BeginInit();
            groupBoxChiTietDHB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudSoLuong).BeginInit();
            groupBoxDHB.SuspendLayout();
            SuspendLayout();
            // 
            // lblThanhTien
            // 
            lblThanhTien.AutoSize = true;
            lblThanhTien.Location = new Point(461, 126);
            lblThanhTien.Name = "lblThanhTien";
            lblThanhTien.Size = new Size(13, 15);
            lblThanhTien.TabIndex = 42;
            lblThanhTien.Text = "0";
            // 
            // btnXoaChiTietDHN
            // 
            btnXoaChiTietDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoaChiTietDHN.Location = new Point(425, 561);
            btnXoaChiTietDHN.Margin = new Padding(3, 2, 3, 2);
            btnXoaChiTietDHN.Name = "btnXoaChiTietDHN";
            btnXoaChiTietDHN.Size = new Size(82, 29);
            btnXoaChiTietDHN.TabIndex = 40;
            btnXoaChiTietDHN.Text = "Xóa";
            btnXoaChiTietDHN.UseVisualStyleBackColor = true;
            btnXoaChiTietDHN.Click += btnXoaChiTietDHN_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnTimKiem);
            groupBox3.Controls.Add(txtMaNCCTimKiem);
            groupBox3.Controls.Add(txtMaDHNTimKiem);
            groupBox3.Controls.Add(maKHTimKiem);
            groupBox3.Controls.Add(maDHBTimKiem);
            groupBox3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.Location = new Point(9, 491);
            groupBox3.Margin = new Padding(3, 2, 3, 2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 2, 3, 2);
            groupBox3.Size = new Size(548, 104);
            groupBox3.TabIndex = 27;
            groupBox3.TabStop = false;
            groupBox3.Text = "Tìm kiếm";
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            btnTimKiem.Location = new Point(402, 47);
            btnTimKiem.Margin = new Padding(3, 2, 3, 2);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(123, 28);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtMaNCCTimKiem
            // 
            txtMaNCCTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaNCCTimKiem.Location = new Point(144, 70);
            txtMaNCCTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaNCCTimKiem.Name = "txtMaNCCTimKiem";
            txtMaNCCTimKiem.Size = new Size(224, 26);
            txtMaNCCTimKiem.TabIndex = 3;
            // 
            // txtMaDHNTimKiem
            // 
            txtMaDHNTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaDHNTimKiem.Location = new Point(144, 30);
            txtMaDHNTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaDHNTimKiem.Name = "txtMaDHNTimKiem";
            txtMaDHNTimKiem.Size = new Size(223, 26);
            txtMaDHNTimKiem.TabIndex = 2;
            // 
            // maKHTimKiem
            // 
            maKHTimKiem.AutoSize = true;
            maKHTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            maKHTimKiem.Location = new Point(4, 75);
            maKHTimKiem.Name = "maKHTimKiem";
            maKHTimKiem.Size = new Size(68, 20);
            maKHTimKiem.TabIndex = 1;
            maKHTimKiem.Text = "Mã NCC";
            // 
            // maDHBTimKiem
            // 
            maDHBTimKiem.AutoSize = true;
            maDHBTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            maDHBTimKiem.Location = new Point(9, 35);
            maDHBTimKiem.Name = "maDHBTimKiem";
            maDHBTimKiem.Size = new Size(70, 20);
            maDHBTimKiem.TabIndex = 0;
            maDHBTimKiem.Text = "Mã ĐHN";
            // 
            // btnSuaChiTietDHN
            // 
            btnSuaChiTietDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnSuaChiTietDHN.Location = new Point(306, 561);
            btnSuaChiTietDHN.Margin = new Padding(3, 2, 3, 2);
            btnSuaChiTietDHN.Name = "btnSuaChiTietDHN";
            btnSuaChiTietDHN.Size = new Size(82, 29);
            btnSuaChiTietDHN.TabIndex = 39;
            btnSuaChiTietDHN.Text = "Sửa";
            btnSuaChiTietDHN.UseVisualStyleBackColor = true;
            btnSuaChiTietDHN.Click += btnSuaChiTietDHN_Click;
            // 
            // btnThemChiTietDHN
            // 
            btnThemChiTietDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnThemChiTietDHN.Location = new Point(200, 561);
            btnThemChiTietDHN.Margin = new Padding(3, 2, 3, 2);
            btnThemChiTietDHN.Name = "btnThemChiTietDHN";
            btnThemChiTietDHN.Size = new Size(82, 29);
            btnThemChiTietDHN.TabIndex = 38;
            btnThemChiTietDHN.Text = "Thêm";
            btnThemChiTietDHN.UseVisualStyleBackColor = true;
            btnThemChiTietDHN.Click += btnThemChiTietDHN_Click;
            // 
            // btnMoiChiTietDHN
            // 
            btnMoiChiTietDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoiChiTietDHN.Location = new Point(94, 561);
            btnMoiChiTietDHN.Margin = new Padding(3, 2, 3, 2);
            btnMoiChiTietDHN.Name = "btnMoiChiTietDHN";
            btnMoiChiTietDHN.Size = new Size(82, 29);
            btnMoiChiTietDHN.TabIndex = 37;
            btnMoiChiTietDHN.Text = "Mới";
            btnMoiChiTietDHN.UseVisualStyleBackColor = true;
            btnMoiChiTietDHN.Click += btnMoiChiTietDHN_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(347, 126);
            label13.Name = "label13";
            label13.Size = new Size(63, 15);
            label13.TabIndex = 8;
            label13.Text = "Thành tiền";
            // 
            // btnXuatExcelDHN
            // 
            btnXuatExcelDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnXuatExcelDHN.Location = new Point(316, 442);
            btnXuatExcelDHN.Margin = new Padding(3, 2, 3, 2);
            btnXuatExcelDHN.Name = "btnXuatExcelDHN";
            btnXuatExcelDHN.Size = new Size(109, 29);
            btnXuatExcelDHN.TabIndex = 38;
            btnXuatExcelDHN.Text = "Xuất Excel";
            btnXuatExcelDHN.UseVisualStyleBackColor = true;
            btnXuatExcelDHN.Click += btnXuatExcelDHN_Click;
            // 
            // btnXoaDHN
            // 
            btnXoaDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoaDHN.Location = new Point(411, 400);
            btnXoaDHN.Margin = new Padding(3, 2, 3, 2);
            btnXoaDHN.Name = "btnXoaDHN";
            btnXoaDHN.Size = new Size(82, 29);
            btnXoaDHN.TabIndex = 36;
            btnXoaDHN.Text = "Xóa";
            btnXoaDHN.UseVisualStyleBackColor = true;
            btnXoaDHN.Click += btnXoaDHN_Click;
            // 
            // lblTongTien
            // 
            lblTongTien.AutoSize = true;
            lblTongTien.Location = new Point(122, 207);
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Size = new Size(13, 15);
            lblTongTien.TabIndex = 11;
            lblTongTien.Text = "0";
            // 
            // lblTenNCC
            // 
            lblTenNCC.AutoSize = true;
            lblTenNCC.Location = new Point(116, 112);
            lblTenNCC.Name = "lblTenNCC";
            lblTenNCC.Size = new Size(63, 15);
            lblTenNCC.TabIndex = 10;
            lblTenNCC.Text = "lblTenNCC";
            // 
            // btnInHoaDonDHN
            // 
            btnInHoaDonDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnInHoaDonDHN.Location = new Point(147, 442);
            btnInHoaDonDHN.Margin = new Padding(3, 2, 3, 2);
            btnInHoaDonDHN.Name = "btnInHoaDonDHN";
            btnInHoaDonDHN.Size = new Size(109, 29);
            btnInHoaDonDHN.TabIndex = 37;
            btnInHoaDonDHN.Text = "In hóa đơn";
            btnInHoaDonDHN.UseVisualStyleBackColor = true;
            btnInHoaDonDHN.Click += btnInHoaDonDHN_Click;
            // 
            // btnSuaDHN
            // 
            btnSuaDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnSuaDHN.Location = new Point(292, 400);
            btnSuaDHN.Margin = new Padding(3, 2, 3, 2);
            btnSuaDHN.Name = "btnSuaDHN";
            btnSuaDHN.Size = new Size(82, 29);
            btnSuaDHN.TabIndex = 35;
            btnSuaDHN.Text = "Sửa";
            btnSuaDHN.UseVisualStyleBackColor = true;
            btnSuaDHN.Click += btnSuaDHN_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 112);
            label6.Name = "label6";
            label6.Size = new Size(53, 15);
            label6.TabIndex = 9;
            label6.Text = "Tên NCC";
            // 
            // btnThemDHN
            // 
            btnThemDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnThemDHN.Location = new Point(186, 400);
            btnThemDHN.Margin = new Padding(3, 2, 3, 2);
            btnThemDHN.Name = "btnThemDHN";
            btnThemDHN.Size = new Size(82, 29);
            btnThemDHN.TabIndex = 34;
            btnThemDHN.Text = "Thêm";
            btnThemDHN.UseVisualStyleBackColor = true;
            btnThemDHN.Click += btnThemDHN_Click;
            // 
            // dgvDonHangNhap
            // 
            dgvDonHangNhap.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDonHangNhap.Location = new Point(6, 241);
            dgvDonHangNhap.Margin = new Padding(3, 2, 3, 2);
            dgvDonHangNhap.Name = "dgvDonHangNhap";
            dgvDonHangNhap.RowHeadersWidth = 51;
            dgvDonHangNhap.Size = new Size(550, 141);
            dgvDonHangNhap.TabIndex = 8;
            dgvDonHangNhap.CellClick += dgvDonHangNhap_CellClick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 207);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 6;
            label5.Text = "Tổng tiền";
            // 
            // btnMoiDHN
            // 
            btnMoiDHN.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoiDHN.Location = new Point(80, 400);
            btnMoiDHN.Margin = new Padding(3, 2, 3, 2);
            btnMoiDHN.Name = "btnMoiDHN";
            btnMoiDHN.Size = new Size(82, 29);
            btnMoiDHN.TabIndex = 33;
            btnMoiDHN.Text = "Mới";
            btnMoiDHN.UseVisualStyleBackColor = true;
            btnMoiDHN.Click += btnMoiDHN_Click;
            // 
            // dtpNgayNhap
            // 
            dtpNgayNhap.CustomFormat = "dd-MM-yyyy";
            dtpNgayNhap.Format = DateTimePickerFormat.Custom;
            dtpNgayNhap.Location = new Point(122, 155);
            dtpNgayNhap.Margin = new Padding(3, 2, 3, 2);
            dtpNgayNhap.Name = "dtpNgayNhap";
            dtpNgayNhap.Size = new Size(219, 23);
            dtpNgayNhap.TabIndex = 5;
            // 
            // cboMaNCC
            // 
            cboMaNCC.FormattingEnabled = true;
            cboMaNCC.Location = new Point(119, 69);
            cboMaNCC.Margin = new Padding(3, 2, 3, 2);
            cboMaNCC.Name = "cboMaNCC";
            cboMaNCC.Size = new Size(133, 23);
            cboMaNCC.TabIndex = 4;
            cboMaNCC.SelectedIndexChanged += cboMaNCC_SelectedIndexChanged;
            // 
            // txtMaDHN
            // 
            txtMaDHN.Location = new Point(122, 26);
            txtMaDHN.Margin = new Padding(3, 2, 3, 2);
            txtMaDHN.Name = "txtMaDHN";
            txtMaDHN.Size = new Size(130, 23);
            txtMaDHN.TabIndex = 3;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(347, 82);
            label12.Name = "label12";
            label12.Size = new Size(48, 15);
            label12.TabIndex = 7;
            label12.Text = "Đơn giá";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(347, 34);
            label11.Name = "label11";
            label11.Size = new Size(54, 15);
            label11.TabIndex = 6;
            label11.Text = "Số lượng";
            // 
            // cboMaSP
            // 
            cboMaSP.FormattingEnabled = true;
            cboMaSP.Location = new Point(109, 75);
            cboMaSP.Margin = new Padding(3, 2, 3, 2);
            cboMaSP.Name = "cboMaSP";
            cboMaSP.Size = new Size(133, 23);
            cboMaSP.TabIndex = 5;
            cboMaSP.SelectedIndexChanged += cboMaSP_SelectedIndexChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(5, 77);
            label10.Name = "label10";
            label10.Size = new Size(87, 15);
            label10.TabIndex = 4;
            label10.Text = "Mã sản phẩm *";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(5, 37);
            label9.Name = "label9";
            label9.Size = new Size(61, 15);
            label9.TabIndex = 1;
            label9.Text = "Mã ĐHN *";
            // 
            // dgvChiTietDonHangNhap
            // 
            dgvChiTietDonHangNhap.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvChiTietDonHangNhap.Location = new Point(5, 173);
            dgvChiTietDonHangNhap.Margin = new Padding(3, 2, 3, 2);
            dgvChiTietDonHangNhap.Name = "dgvChiTietDonHangNhap";
            dgvChiTietDonHangNhap.RowHeadersWidth = 51;
            dgvChiTietDonHangNhap.Size = new Size(590, 340);
            dgvChiTietDonHangNhap.TabIndex = 0;
            dgvChiTietDonHangNhap.CellClick += dgvChiTietDonHangNhap_CellClick;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 159);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 2;
            label4.Text = "Ngày nhập";
            // 
            // lblTenSanPham
            // 
            lblTenSanPham.AutoSize = true;
            lblTenSanPham.Location = new Point(109, 126);
            lblTenSanPham.Name = "lblTenSanPham";
            lblTenSanPham.Size = new Size(0, 15);
            lblTenSanPham.TabIndex = 44;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(5, 126);
            label15.Name = "label15";
            label15.Size = new Size(80, 15);
            label15.TabIndex = 43;
            label15.Text = "Tên sản phẩm";
            // 
            // groupBoxChiTietDHB
            // 
            groupBoxChiTietDHB.Controls.Add(txtDonGia);
            groupBoxChiTietDHB.Controls.Add(nudSoLuong);
            groupBoxChiTietDHB.Controls.Add(lblTenSanPham);
            groupBoxChiTietDHB.Controls.Add(label15);
            groupBoxChiTietDHB.Controls.Add(txtMaDHNChiTiet);
            groupBoxChiTietDHB.Controls.Add(lblThanhTien);
            groupBoxChiTietDHB.Controls.Add(btnXoaChiTietDHN);
            groupBoxChiTietDHB.Controls.Add(btnSuaChiTietDHN);
            groupBoxChiTietDHB.Controls.Add(btnThemChiTietDHN);
            groupBoxChiTietDHB.Controls.Add(btnMoiChiTietDHN);
            groupBoxChiTietDHB.Controls.Add(label13);
            groupBoxChiTietDHB.Controls.Add(label12);
            groupBoxChiTietDHB.Controls.Add(label11);
            groupBoxChiTietDHB.Controls.Add(cboMaSP);
            groupBoxChiTietDHB.Controls.Add(label10);
            groupBoxChiTietDHB.Controls.Add(label9);
            groupBoxChiTietDHB.Controls.Add(dgvChiTietDonHangNhap);
            groupBoxChiTietDHB.Location = new Point(641, 33);
            groupBoxChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            groupBoxChiTietDHB.Name = "groupBoxChiTietDHB";
            groupBoxChiTietDHB.Padding = new Padding(3, 2, 3, 2);
            groupBoxChiTietDHB.Size = new Size(600, 613);
            groupBoxChiTietDHB.TabIndex = 5;
            groupBoxChiTietDHB.TabStop = false;
            groupBoxChiTietDHB.Text = "Chi tiết hóa đơn";
            // 
            // txtDonGia
            // 
            txtDonGia.Location = new Point(425, 77);
            txtDonGia.Margin = new Padding(3, 2, 3, 2);
            txtDonGia.Name = "txtDonGia";
            txtDonGia.Size = new Size(130, 23);
            txtDonGia.TabIndex = 45;
            // 
            // nudSoLuong
            // 
            nudSoLuong.Location = new Point(425, 32);
            nudSoLuong.Margin = new Padding(3, 2, 3, 2);
            nudSoLuong.Name = "nudSoLuong";
            nudSoLuong.Size = new Size(131, 23);
            nudSoLuong.TabIndex = 39;
            nudSoLuong.ValueChanged += nudSoLuong_ValueChanged;
            // 
            // txtMaDHNChiTiet
            // 
            txtMaDHNChiTiet.Location = new Point(109, 32);
            txtMaDHNChiTiet.Margin = new Padding(3, 2, 3, 2);
            txtMaDHNChiTiet.Name = "txtMaDHNChiTiet";
            txtMaDHNChiTiet.Size = new Size(130, 23);
            txtMaDHNChiTiet.TabIndex = 39;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 75);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 1;
            label3.Text = "Mã NCC *";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 28);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 0;
            label2.Text = "Mã ĐHN *";
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // groupBoxDHB
            // 
            groupBoxDHB.Controls.Add(groupBox3);
            groupBoxDHB.Controls.Add(btnXuatExcelDHN);
            groupBoxDHB.Controls.Add(btnXoaDHN);
            groupBoxDHB.Controls.Add(lblTongTien);
            groupBoxDHB.Controls.Add(lblTenNCC);
            groupBoxDHB.Controls.Add(btnInHoaDonDHN);
            groupBoxDHB.Controls.Add(btnSuaDHN);
            groupBoxDHB.Controls.Add(label6);
            groupBoxDHB.Controls.Add(btnThemDHN);
            groupBoxDHB.Controls.Add(dgvDonHangNhap);
            groupBoxDHB.Controls.Add(label5);
            groupBoxDHB.Controls.Add(btnMoiDHN);
            groupBoxDHB.Controls.Add(dtpNgayNhap);
            groupBoxDHB.Controls.Add(cboMaNCC);
            groupBoxDHB.Controls.Add(txtMaDHN);
            groupBoxDHB.Controls.Add(label4);
            groupBoxDHB.Controls.Add(label3);
            groupBoxDHB.Controls.Add(label2);
            groupBoxDHB.Location = new Point(48, 33);
            groupBoxDHB.Margin = new Padding(3, 2, 3, 2);
            groupBoxDHB.Name = "groupBoxDHB";
            groupBoxDHB.Padding = new Padding(3, 2, 3, 2);
            groupBoxDHB.Size = new Size(572, 613);
            groupBoxDHB.TabIndex = 4;
            groupBoxDHB.TabStop = false;
            groupBoxDHB.Text = "Thông tin hóa đơn";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(545, 4);
            label1.Name = "label1";
            label1.Size = new Size(199, 20);
            label1.TabIndex = 3;
            label1.Text = "HÓA ĐƠN NHẬP HÀNG";
            // 
            // GUI_HDNhapHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1310, 688);
            Controls.Add(groupBoxChiTietDHB);
            Controls.Add(groupBoxDHB);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GUI_HDNhapHang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GUI_HDNhapHang";
            Load += GUI_HDNhapHang_Load;
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDonHangNhap).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonHangNhap).EndInit();
            groupBoxChiTietDHB.ResumeLayout(false);
            groupBoxChiTietDHB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudSoLuong).EndInit();
            groupBoxDHB.ResumeLayout(false);
            groupBoxDHB.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblThanhTien;
        private Button btnXoaChiTietDHN;
        private GroupBox groupBox3;
        private Button btnTimKiem;
        private TextBox txtMaNCCTimKiem;
        private TextBox txtMaDHNTimKiem;
        private Label maKHTimKiem;
        private Label maDHBTimKiem;
        private Button btnSuaChiTietDHN;
        private Button btnThemChiTietDHN;
        private Button btnMoiChiTietDHN;
        private Label label13;
        private Button btnXuatExcelDHN;
        private Button btnXoaDHN;
        private Label lblTongTien;
        private Label lblTenNCC;
        private Button btnInHoaDonDHN;
        private Button btnSuaDHN;
        private Label label6;
        private Button btnThemDHN;
        private DataGridView dgvDonHangNhap;
        private Label label5;
        private Button btnMoiDHN;
        private DateTimePicker dtpNgayNhap;
        private ComboBox cboMaNCC;
        private TextBox txtMaDHN;
        private Label label12;
        private Label label11;
        private ComboBox cboMaSP;
        private Label label10;
        private Label label9;
        private DataGridView dgvChiTietDonHangNhap;
        private PrintPreviewDialog printPreviewDialog1;
        private Label label4;
        private Label lblTenSanPham;
        private Label label15;
        private GroupBox groupBoxChiTietDHB;
        private NumericUpDown nudSoLuong;
        private TextBox txtMaDHNChiTiet;
        private Label label3;
        private Label label2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private GroupBox groupBoxDHB;
        private Label label1;
        private TextBox txtDonGia;
    }
}