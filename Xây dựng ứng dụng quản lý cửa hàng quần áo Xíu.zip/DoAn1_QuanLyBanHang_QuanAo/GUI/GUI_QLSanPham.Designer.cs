﻿namespace GUI
{
    partial class GUI_QLSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            errorProvider1 = new ErrorProvider(components);
            label2 = new Label();
            label3 = new Label();
            btnTimKiem = new Button();
            txtTenSPTimKiem = new TextBox();
            txtMaSP = new TextBox();
            btnXoa = new Button();
            txtTenSP = new TextBox();
            btnThoat = new Button();
            label5 = new Label();
            btnSua = new Button();
            btnThem = new Button();
            btnMoi = new Button();
            groupBox1 = new GroupBox();
            txtMoTa = new TextBox();
            label11 = new Label();
            txtSoLuong = new TextBox();
            label10 = new Label();
            txtDonGiaBan = new TextBox();
            label8 = new Label();
            label4 = new Label();
            cboLoaiHang = new ComboBox();
            label9 = new Label();
            btnChonAnh = new Button();
            picAnhSP = new PictureBox();
            txtMaSPTimKiem = new TextBox();
            label6 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            dgvSanPham = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picAnhSP).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSanPham).BeginInit();
            SuspendLayout();
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9F);
            label2.Location = new Point(12, 34);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã SP *";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 9F);
            label3.Location = new Point(12, 74);
            label3.Name = "label3";
            label3.Size = new Size(94, 15);
            label3.TabIndex = 2;
            label3.Text = "Tên sản phẩm *";
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            btnTimKiem.Location = new Point(808, 25);
            btnTimKiem.Margin = new Padding(3, 2, 3, 2);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(123, 28);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtTenSPTimKiem
            // 
            txtTenSPTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtTenSPTimKiem.Location = new Point(448, 30);
            txtTenSPTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtTenSPTimKiem.Name = "txtTenSPTimKiem";
            txtTenSPTimKiem.Size = new Size(325, 26);
            txtTenSPTimKiem.TabIndex = 3;
            // 
            // txtMaSP
            // 
            txtMaSP.Font = new Font("Microsoft Sans Serif", 9F);
            txtMaSP.Location = new Point(128, 29);
            txtMaSP.Margin = new Padding(3, 2, 3, 2);
            txtMaSP.Name = "txtMaSP";
            txtMaSP.Size = new Size(267, 21);
            txtMaSP.TabIndex = 4;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoa.Location = new Point(584, 457);
            btnXoa.Margin = new Padding(3, 2, 3, 2);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(82, 29);
            btnXoa.TabIndex = 40;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // txtTenSP
            // 
            txtTenSP.Font = new Font("Microsoft Sans Serif", 9F);
            txtTenSP.Location = new Point(128, 70);
            txtTenSP.Margin = new Padding(3, 2, 3, 2);
            txtTenSP.Name = "txtTenSP";
            txtTenSP.Size = new Size(267, 21);
            txtTenSP.TabIndex = 6;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Microsoft Sans Serif", 12F);
            btnThoat.Location = new Point(759, 457);
            btnThoat.Margin = new Padding(3, 2, 3, 2);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(82, 29);
            btnThoat.TabIndex = 41;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F);
            label5.Location = new Point(9, 35);
            label5.Name = "label5";
            label5.Size = new Size(56, 20);
            label5.TabIndex = 0;
            label5.Text = "Mã SP";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Microsoft Sans Serif", 12F);
            btnSua.Location = new Point(410, 457);
            btnSua.Margin = new Padding(3, 2, 3, 2);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(82, 29);
            btnSua.TabIndex = 39;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Microsoft Sans Serif", 12F);
            btnThem.Location = new Point(236, 457);
            btnThem.Margin = new Padding(3, 2, 3, 2);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(82, 29);
            btnThem.TabIndex = 38;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnMoi
            // 
            btnMoi.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoi.Location = new Point(62, 457);
            btnMoi.Margin = new Padding(3, 2, 3, 2);
            btnMoi.Name = "btnMoi";
            btnMoi.Size = new Size(82, 29);
            btnMoi.TabIndex = 37;
            btnMoi.Text = "Mới";
            btnMoi.UseVisualStyleBackColor = true;
            btnMoi.Click += btnMoi_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtMoTa);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(txtSoLuong);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(txtDonGiaBan);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(cboLoaiHang);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(btnChonAnh);
            groupBox1.Controls.Add(picAnhSP);
            groupBox1.Controls.Add(txtTenSP);
            groupBox1.Controls.Add(txtMaSP);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(10, 9);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(950, 201);
            groupBox1.TabIndex = 34;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin sản phẩm";
            // 
            // txtMoTa
            // 
            txtMoTa.Location = new Point(125, 152);
            txtMoTa.Margin = new Padding(3, 2, 3, 2);
            txtMoTa.Multiline = true;
            txtMoTa.Name = "txtMoTa";
            txtMoTa.Size = new Size(632, 45);
            txtMoTa.TabIndex = 21;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(14, 155);
            label11.Name = "label11";
            label11.Size = new Size(38, 15);
            label11.TabIndex = 20;
            label11.Text = "Mô tả";
            // 
            // txtSoLuong
            // 
            txtSoLuong.Font = new Font("Microsoft Sans Serif", 9F);
            txtSoLuong.Location = new Point(528, 66);
            txtSoLuong.Margin = new Padding(3, 2, 3, 2);
            txtSoLuong.Name = "txtSoLuong";
            txtSoLuong.Size = new Size(230, 21);
            txtSoLuong.TabIndex = 19;
            txtSoLuong.KeyPress += txtSoLuong_KeyPress;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F);
            label10.Location = new Point(418, 68);
            label10.Name = "label10";
            label10.Size = new Size(56, 15);
            label10.TabIndex = 18;
            label10.Text = "Số lượng";
            // 
            // txtDonGiaBan
            // 
            txtDonGiaBan.Font = new Font("Microsoft Sans Serif", 9F);
            txtDonGiaBan.Location = new Point(528, 27);
            txtDonGiaBan.Margin = new Padding(3, 2, 3, 2);
            txtDonGiaBan.Name = "txtDonGiaBan";
            txtDonGiaBan.Size = new Size(230, 21);
            txtDonGiaBan.TabIndex = 17;
            txtDonGiaBan.KeyPress += txtDonGiaBan_KeyPress;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(418, 29);
            label8.Name = "label8";
            label8.Size = new Size(74, 15);
            label8.TabIndex = 16;
            label8.Text = "Đơn giá bán";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 113);
            label4.Name = "label4";
            label4.Size = new Size(70, 15);
            label4.TabIndex = 15;
            label4.Text = "Loại hàng *";
            // 
            // cboLoaiHang
            // 
            cboLoaiHang.FormattingEnabled = true;
            cboLoaiHang.Location = new Point(128, 107);
            cboLoaiHang.Margin = new Padding(3, 2, 3, 2);
            cboLoaiHang.Name = "cboLoaiHang";
            cboLoaiHang.Size = new Size(267, 23);
            cboLoaiHang.TabIndex = 14;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(809, 169);
            label9.Name = "label9";
            label9.Size = new Size(28, 15);
            label9.TabIndex = 13;
            label9.Text = "Ảnh";
            // 
            // btnChonAnh
            // 
            btnChonAnh.Location = new Point(850, 165);
            btnChonAnh.Margin = new Padding(3, 2, 3, 2);
            btnChonAnh.Name = "btnChonAnh";
            btnChonAnh.Size = new Size(82, 22);
            btnChonAnh.TabIndex = 12;
            btnChonAnh.Text = "Chọn";
            btnChonAnh.UseVisualStyleBackColor = true;
            btnChonAnh.Click += btnChonAnh_Click;
            // 
            // picAnhSP
            // 
            picAnhSP.Location = new Point(808, 29);
            picAnhSP.Margin = new Padding(3, 2, 3, 2);
            picAnhSP.Name = "picAnhSP";
            picAnhSP.Size = new Size(124, 122);
            picAnhSP.TabIndex = 11;
            picAnhSP.TabStop = false;
            // 
            // txtMaSPTimKiem
            // 
            txtMaSPTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaSPTimKiem.Location = new Point(132, 33);
            txtMaSPTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaSPTimKiem.Name = "txtMaSPTimKiem";
            txtMaSPTimKiem.Size = new Size(148, 26);
            txtMaSPTimKiem.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F);
            label6.Location = new Point(293, 35);
            label6.Name = "label6";
            label6.Size = new Size(110, 20);
            label6.TabIndex = 1;
            label6.Text = "Tên sản phẩm";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F);
            label1.Location = new Point(308, -63);
            label1.Name = "label1";
            label1.Size = new Size(145, 20);
            label1.TabIndex = 33;
            label1.Text = "Quản Lý Loại Hàng";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnTimKiem);
            groupBox2.Controls.Add(txtTenSPTimKiem);
            groupBox2.Controls.Add(txtMaSPTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(10, 510);
            groupBox2.Margin = new Padding(3, 2, 3, 2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 2, 3, 2);
            groupBox2.Size = new Size(950, 62);
            groupBox2.TabIndex = 35;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // dgvSanPham
            // 
            dgvSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSanPham.Location = new Point(10, 224);
            dgvSanPham.Margin = new Padding(3, 2, 3, 2);
            dgvSanPham.Name = "dgvSanPham";
            dgvSanPham.RowHeadersWidth = 51;
            dgvSanPham.Size = new Size(950, 206);
            dgvSanPham.TabIndex = 36;
            dgvSanPham.CellClick += dgvSanPham_CellClick;
            // 
            // GUI_QLSanPham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(971, 635);
            Controls.Add(btnXoa);
            Controls.Add(btnThoat);
            Controls.Add(btnSua);
            Controls.Add(btnThem);
            Controls.Add(btnMoi);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(dgvSanPham);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GUI_QLSanPham";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GUI_QLSanPham";
            Load += GUI_QLSanPham_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picAnhSP).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSanPham).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ErrorProvider errorProvider1;
        private Button btnXoa;
        private Button btnThoat;
        private Button btnSua;
        private Button btnThem;
        private Button btnMoi;
        private GroupBox groupBox1;
        private TextBox txtTenSP;
        private TextBox txtMaSP;
        private Label label2;
        private Label label3;
        private Label label1;
        private GroupBox groupBox2;
        private Button btnTimKiem;
        private TextBox txtTenSPTimKiem;
        private TextBox txtMaSPTimKiem;
        private Label label6;
        private Label label5;
        private DataGridView dgvSanPham;
        private Label label9;
        private Button btnChonAnh;
        private PictureBox picAnhSP;
        private Label label4;
        private ComboBox cboLoaiHang;
        private TextBox txtMoTa;
        private Label label11;
        private TextBox txtSoLuong;
        private Label label10;
        private TextBox txtDonGiaBan;
        private Label label8;
    }
}