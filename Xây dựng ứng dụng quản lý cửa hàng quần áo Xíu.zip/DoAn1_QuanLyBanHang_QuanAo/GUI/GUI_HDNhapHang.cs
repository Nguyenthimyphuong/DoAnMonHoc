﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class GUI_HDNhapHang : Form
    {
        BLL_DonHangNhap bllDonHangNhap = new BLL_DonHangNhap();
        BLL_ChiTietDonHangNhap bllChiTietDonHangNhap = new BLL_ChiTietDonHangNhap();
        BLL_NhaCungCap bllNhaCungCap = new BLL_NhaCungCap();
        BLL_SanPham bllSanPham = new BLL_SanPham();

        public GUI_HDNhapHang()
        {
            InitializeComponent();
        }

        void LoadDataDonHangNhap()
        {
            // Load comboBox Nhà Cung Cấp
            cboMaNCC.DataSource = bllNhaCungCap.GetAllNhaCungCap();
            cboMaNCC.DisplayMember = "MaNCC";
            cboMaNCC.ValueMember = "MaNCC";
            cboMaNCC.SelectedIndex = -1;

            // Load DataGridView
            dgvDonHangNhap.DataSource = bllDonHangNhap.GetAllDonHangNhap();
            dgvDonHangNhap.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDonHangNhap.Columns["MaDHN"].HeaderText = "Mã ĐHN";
            dgvDonHangNhap.Columns["MaNCC"].HeaderText = "Mã NCC";
            dgvDonHangNhap.Columns["TenNCC"].HeaderText = "Tên NCC";
            dgvDonHangNhap.Columns["NgayNhap"].HeaderText = "Ngày Nhập";
            dgvDonHangNhap.Columns["TongTien"].HeaderText = "Tổng Tiền";

            dgvDonHangNhap.Columns["NgayNhap"].DefaultCellStyle.Format = "dd/MM/yyyy";
        }

        void LoadDataChiTietDonHangNhap()
        {
            // Load comboBox Sản Phẩm
            cboMaSP.DataSource = bllSanPham.GetAllSanPham();
            cboMaSP.DisplayMember = "MaSP";
            cboMaSP.ValueMember = "MaSP";

            // Load dữ liệu chi tiết đơn hàng nhập tương ứng
            DataTable dtChiTiet = bllChiTietDonHangNhap.GetChiTietTheoMaDHN(txtMaDHNChiTiet.Text);

            // Thêm cột STT
            if (!dtChiTiet.Columns.Contains("STT"))
                dtChiTiet.Columns.Add("STT", typeof(int));

            for (int i = 0; i < dtChiTiet.Rows.Count; i++)
            {
                dtChiTiet.Rows[i]["STT"] = i + 1;
            }

            dgvChiTietDonHangNhap.DataSource = dtChiTiet;
            dgvChiTietDonHangNhap.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgvChiTietDonHangNhap.Columns["STT"].DisplayIndex = 0;
            dgvChiTietDonHangNhap.Columns["MaDHN"].DisplayIndex = 1;
            dgvChiTietDonHangNhap.Columns["MaSP"].DisplayIndex = 2;
            dgvChiTietDonHangNhap.Columns["TenSP"].DisplayIndex = 3;
            dgvChiTietDonHangNhap.Columns["SoLuong"].DisplayIndex = 4;
            dgvChiTietDonHangNhap.Columns["DonGia"].DisplayIndex = 5;
            dgvChiTietDonHangNhap.Columns["ThanhTien"].DisplayIndex = 6;

            dgvChiTietDonHangNhap.Columns["STT"].HeaderText = "STT";
            dgvChiTietDonHangNhap.Columns["MaDHN"].HeaderText = "Mã ĐHN";
            dgvChiTietDonHangNhap.Columns["MaSP"].HeaderText = "Mã SP";
            dgvChiTietDonHangNhap.Columns["TenSP"].HeaderText = "Tên SP";
            dgvChiTietDonHangNhap.Columns["SoLuong"].HeaderText = "Số lượng";
            dgvChiTietDonHangNhap.Columns["DonGia"].HeaderText = "Đơn giá";
            dgvChiTietDonHangNhap.Columns["ThanhTien"].HeaderText = "Thành tiền";

            dgvChiTietDonHangNhap.Columns["MaCTDHN"].Visible = false;
            dgvChiTietDonHangNhap.Columns["MaDHN"].Visible = false;
            dgvChiTietDonHangNhap.Columns["STT"].Width = 50;
            dgvChiTietDonHangNhap.Columns["MaSP"].Width = 50;
        }

        void TinhTongTien()
        {
            decimal tongTien = 0;
            foreach (DataGridViewRow row in dgvChiTietDonHangNhap.Rows)
            {
                if (row.Cells["ThanhTien"].Value != null)
                {
                    tongTien += Convert.ToDecimal(row.Cells["ThanhTien"].Value);
                }
            }
            lblTongTien.Text = tongTien.ToString("N0") + " VNĐ"; // Định dạng tiền
        }

        void TinhThanhTien()
        {
            // Loại bỏ "VNĐ" và dấu phân tách hàng ngàn nếu có
            string donGiaText = txtDonGia.Text;
            if (decimal.TryParse(donGiaText, out decimal donGia))
            {
                int soLuong = (int)nudSoLuong.Value;
                decimal thanhTien = donGia * soLuong;
                lblThanhTien.Text = thanhTien.ToString("N0") + " VNĐ"; // Format tiền tệ
            }
            else
            {
                lblThanhTien.Text = "0 VNĐ";
            }
        }

        private void GUI_HDNhapHang_Load(object sender, EventArgs e)
        {
            txtMaDHNChiTiet.Enabled = false; // Không cho phép nhập mã HDN chi tiết
            LoadDataDonHangNhap();

            // Thiết lập giới hạn số lượng sản phẩm
            nudSoLuong.Minimum = 1;
            nudSoLuong.Maximum = 1000;
        }

        private void btnMoiDHN_Click(object sender, EventArgs e)
        {
            txtMaDHN.Enabled = true; // Cho phép nhập mã HDN mới
            txtMaDHN.Clear();
            cboMaNCC.SelectedIndex = -1;
            dtpNgayNhap.Value = DateTime.Now;
            lblTongTien.Text = "0 VNĐ";
            lblTenNCC.Text = "";
            txtMaDHNChiTiet.Clear();
            txtMaDHNTimKiem.Clear();
            txtMaNCCTimKiem.Clear();
            dgvChiTietDonHangNhap.DataSource = null; // Xóa dữ liệu chi tiết đơn hàng nhập

            txtMaDHN.Focus();
            LoadDataDonHangNhap();
        }

        private void btnThemDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maHDN = txtMaDHN.Text.Trim();

                if (cboMaNCC.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn Mã nhà cung cấp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string maNCC = cboMaNCC.SelectedValue.ToString();
                DateTime ngayNhap = dtpNgayNhap.Value;
                string tongTienText = lblTongTien.Text.Replace("VNĐ", "").Trim().Replace(",", "");
                decimal tongTien;

                if (!decimal.TryParse(tongTienText, out tongTien))
                {
                    MessageBox.Show("Tổng tiền không hợp lệ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrEmpty(maHDN) || string.IsNullOrEmpty(maNCC))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ Mã HDN và Mã nhà cung cấp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_DonHangNhap hdn = new DTO_DonHangNhap(maHDN, maNCC, ngayNhap, tongTien);
                if (bllDonHangNhap.ThemDonHangNhap(hdn))
                {
                    MessageBox.Show("Thêm hóa đơn nhập thành công");
                    LoadDataDonHangNhap();
                }
                else
                {
                    MessageBox.Show("Mã HDN đã tồn tại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnSuaDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maHDN = txtMaDHN.Text.Trim();

                if (cboMaNCC.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn Mã nhà cung cấp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string maNCC = cboMaNCC.SelectedValue.ToString();
                DateTime ngayNhap = dtpNgayNhap.Value;
                string tongTienText = lblTongTien.Text.Replace("VNĐ", "").Trim().Replace(",", "");
                decimal tongTien = tongTienText == "" ? 0 : decimal.Parse(tongTienText);

                if (string.IsNullOrEmpty(maHDN))
                {
                    MessageBox.Show("Vui lòng chọn hóa đơn nhập cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DTO_DonHangNhap hdn = new DTO_DonHangNhap(maHDN, maNCC, ngayNhap, tongTien);

                if (bllDonHangNhap.SuaDonHangNhap(hdn))
                {
                    MessageBox.Show("Sửa hóa đơn nhập thành công");
                    LoadDataDonHangNhap();
                }
                else
                {
                    MessageBox.Show("Mã HDN không tồn tại");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnXoaDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maHDN = txtMaDHN.Text.Trim();

                if (string.IsNullOrEmpty(maHDN))
                {
                    MessageBox.Show("Vui lòng chọn hóa đơn nhập cần xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa hóa đơn nhập này? Lưu ý: Tất cả dữ liệu chi tiết liên quan sẽ bị xóa.",
                                          "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (bllDonHangNhap.XoaDonHangNhap(maHDN))
                    {
                        MessageBox.Show("Xóa hóa đơn nhập thành công");
                        LoadDataDonHangNhap();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy hóa đơn nhập để xóa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInHoaDonDHN_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnXuatExcelDHN_Click(object sender, EventArgs e)
        {

        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string maDHN = txtMaDHNTimKiem.Text.Trim();
            string maNCC = txtMaNCCTimKiem.Text.Trim();

            if (string.IsNullOrEmpty(maDHN) && string.IsNullOrEmpty(maNCC))
            {
                MessageBox.Show("Vui lòng nhập Mã ĐHN hoặc Mã NCC để tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable dt = bllDonHangNhap.TimKiemDonHangNhap(maDHN, maNCC);
            dgvDonHangNhap.DataSource = dt;
        }

        private void dgvDonHangNhap_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                if (rowIndex < 0) return;

                // Lấy dữ liệu từ dòng đã chọn
                DataGridViewRow row = dgvDonHangNhap.Rows[rowIndex];
                string maHDN = row.Cells["MaDHN"].Value.ToString();
                string maNCC = row.Cells["MaNCC"].Value.ToString();
                DateTime ngayNhap = Convert.ToDateTime(row.Cells["NgayNhap"].Value);
                decimal tongTien = Convert.ToDecimal(row.Cells["TongTien"].Value);

                // Cập nhật thông tin vào các điều khiển
                txtMaDHN.Text = maHDN;
                txtMaDHNChiTiet.Text = maHDN; // Cập nhật mã HDN chi tiết
                cboMaNCC.SelectedValue = maNCC;
                dtpNgayNhap.Value = ngayNhap;
                lblTongTien.Text = tongTien.ToString("N0") + " VNĐ"; // Định dạng tiền 

                // Load dữ liệu chi tiết đơn hàng nhập
                LoadDataChiTietDonHangNhap();
                txtMaDHN.Enabled = false; // Không cho phép sửa mã HDN

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cboMaNCC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMaNCC.SelectedIndex >= 0 && cboMaNCC.SelectedValue != null)
            {
                string maNCC = cboMaNCC.SelectedValue.ToString();
                DataTable dt = bllNhaCungCap.TimKiemNhaCungCap(maNCC, "");

                if (dt.Rows.Count > 0)
                {
                    lblTenNCC.Text = dt.Rows[0]["TenNCC"].ToString();
                }
                else
                {
                    lblTenNCC.Text = "";
                }
            }
            else
            {
                lblTenNCC.Text = "";
            }
        }

        private void dgvChiTietDonHangNhap_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                if (rowIndex < 0) return;

                DataGridViewRow row = dgvChiTietDonHangNhap.Rows[rowIndex];

                decimal donGia = Convert.ToDecimal(row.Cells["DonGia"].Value);
                decimal thanhTien = Convert.ToDecimal(row.Cells["ThanhTien"].Value);
                cboMaSP.SelectedValue = row.Cells["MaSP"].Value.ToString();
                nudSoLuong.Value = Convert.ToInt32(row.Cells["SoLuong"].Value);
                txtDonGia.Text = donGia.ToString("N0");
                lblThanhTien.Text = thanhTien.ToString("N0") + " VNĐ";

                cboMaSP.Enabled = false; // Không cho phép thay đổi mã sản phẩm
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void cboMaSP_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMaSP.SelectedIndex >= 0 && cboMaSP.SelectedValue != null)
            {
                string maSP = cboMaSP.SelectedValue.ToString();

                // Tìm kiếm sản phẩm theo mã
                DataTable dt = bllSanPham.TimKiemSanPham(maSP, "");

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    // Hiển thị tên sản phẩm
                    lblTenSanPham.Text = row["TenSP"].ToString();

                }
                else
                {
                    lblTenSanPham.Text = "";
                    txtDonGia.Text = "";
                    lblThanhTien.Text = "";
                }
            }
            else
            {
                lblTenSanPham.Text = "";
                txtDonGia.Text = "";
                lblThanhTien.Text = "";
            }
        }

        private void nudSoLuong_ValueChanged(object sender, EventArgs e)
        {
            TinhThanhTien();
        }

        private void btnMoiChiTietDHN_Click(object sender, EventArgs e)
        {
            //txtMaDHBChiTiet.Clear();
            cboMaSP.SelectedIndex = -1;
            lblTenSanPham.Text = "";
            nudSoLuong.Value = 1;
            txtDonGia.Text = "";
            lblThanhTien.Text = "0 VNĐ";
            //dgvChiTietDonHangBan.DataSource = null;

            cboMaSP.Enabled = true; // Cho phép chọn sản phẩm mới
        }

        private void btnThemChiTietDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHN = txtMaDHNChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHN))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHNChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();
                int soLuong = (int)nudSoLuong.Value;

                decimal donGia = txtDonGia.Text == "" ? 0 : decimal.Parse(txtDonGia.Text);
                decimal thanhTien = donGia * soLuong;

                DTO_ChiTietDonHangNhap ct = new DTO_ChiTietDonHangNhap(maDHN, maSP, soLuong, donGia, thanhTien);
                if (bllChiTietDonHangNhap.ThemChiTietDonHangNhap(ct))
                {
                    MessageBox.Show("Thêm chi tiết đơn hàng nhập thành công");
                    LoadDataChiTietDonHangNhap();
                    LoadDataDonHangNhap();
                    TinhTongTien();
                }
                else
                {
                    MessageBox.Show("Sản phẩm đã tồn tại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnSuaChiTietDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHN = txtMaDHNChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHN))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHNChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();
                int soLuong = (int)nudSoLuong.Value;

                decimal donGia = txtDonGia.Text == "" ? 0 : decimal.Parse(txtDonGia.Text);
                decimal thanhTien = donGia * soLuong;

                DTO_ChiTietDonHangNhap ct = new DTO_ChiTietDonHangNhap(maDHN, maSP, soLuong, donGia, thanhTien);
                if (bllChiTietDonHangNhap.SuaChiTietDonHangNhap(ct))
                {
                    MessageBox.Show("Sửa chi tiết đơn hàng nhập thành công");
                    LoadDataChiTietDonHangNhap();
                    LoadDataDonHangNhap();
                    TinhTongTien();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy chi tiết để sửa");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnXoaChiTietDHN_Click(object sender, EventArgs e)
        {
            try
            {
                string maDHN = txtMaDHNChiTiet.Text.Trim();

                // Kiểm tra mã đơn hàng
                if (string.IsNullOrEmpty(maDHN))
                {
                    MessageBox.Show("Vui lòng chọn mã đơn hàng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDHNChiTiet.Focus();
                    return;
                }

                // Kiểm tra mã sản phẩm
                if (cboMaSP.SelectedIndex == -1 || cboMaSP.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn mã sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboMaSP.Focus();
                    return;
                }

                string maSP = cboMaSP.SelectedValue.ToString();

                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa chi tiết sản phẩm này?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (bllChiTietDonHangNhap.XoaChiTietDonHangNhap(maDHN, maSP))
                    {
                        MessageBox.Show("Xóa chi tiết thành công");
                        LoadDataChiTietDonHangNhap();
                        LoadDataDonHangNhap();
                        TinhTongTien();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy chi tiết để xóa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font titleFont = new Font("Arial", 20, FontStyle.Bold);
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);
            Font textFont = new Font("Arial", 12);
            SolidBrush blueBrush = new SolidBrush(Color.Blue);
            SolidBrush blackBrush = new SolidBrush(Color.Black);

            int y = 50; // Vị trí bắt đầu y

            // 1. Tiêu đề: SHOP 
            string title = "SHOP QUAN AO";
            SizeF titleSize = g.MeasureString(title, titleFont);
            g.DrawString(title, titleFont, blueBrush, (e.PageBounds.Width - titleSize.Width) / 2, y);
            y += 50;

            // 2. Mã hóa đơn nhập và ngày
            g.DrawString("Mã hóa đơn nhập: " + txtMaDHN.Text, textFont, blackBrush, 50, y);
            DateTime ngayNhap = Convert.ToDateTime(dgvDonHangNhap.CurrentRow.Cells["NgayNhap"].Value);
            g.DrawString("Ngày: " + ngayNhap.ToString("dd/MM/yyyy"), textFont, blackBrush, e.PageBounds.Width - 250, y);
            y += 40;

            // 3. Thông tin nhà cung cấp
            g.DrawString("THÔNG TIN NHÀ CUNG CẤP", headerFont, blackBrush, 50, y);
            y += 30;

            string tenNCC = lblTenNCC.Text;
            //string diaChi = bllNhaCungCap.GetDiaChiTheoMaNCC(cboMaNCC.SelectedValue.ToString());
            //string sdt = bllNhaCungCap.GetSDTTheoMaNCC(cboMaNCC.SelectedValue.ToString());

            g.DrawString("Tên nhà cung cấp: " + tenNCC, textFont, blackBrush, 70, y); y += 25;
            //g.DrawString("Địa chỉ: " + diaChi, textFont, blackBrush, 70, y); y += 25;
            //g.DrawString("SĐT: " + sdt, textFont, blackBrush, 70, y); y += 30;

            // 4. Vẽ bảng sản phẩm nhập
            int startX = 50;
            int tableWidth = e.PageBounds.Width - 100;
            int[] colWidths = { 50, 250, 100, 100, 120 };
            string[] headers = { "STT", "Tên SP", "Đơn giá", "Số lượng", "Thành tiền" };

            int tableY = y;

            // Header bảng
            int colX = startX;
            for (int i = 0; i < headers.Length; i++)
            {
                g.DrawRectangle(Pens.Black, colX, tableY, colWidths[i], 30);
                g.DrawString(headers[i], headerFont, blackBrush, colX + 5, tableY + 5);
                colX += colWidths[i];
            }
            tableY += 30;

            // Dữ liệu sản phẩm
            int stt = 1;
            foreach (DataGridViewRow row in dgvChiTietDonHangNhap.Rows)
            {
                if (row.IsNewRow) continue;

                string tenSP = row.Cells["TenSP"].Value?.ToString() ?? "";
                string donGia = string.Format("{0:N0}", row.Cells["DonGia"].Value);
                string soLuong = row.Cells["SoLuong"].Value?.ToString() ?? "";
                string thanhTien = string.Format("{0:N0}", row.Cells["ThanhTien"].Value);

                string[] rowData = {
                    stt.ToString(),
                    tenSP,
                    donGia,
                    soLuong,
                    thanhTien
                 };

                colX = startX;
                for (int i = 0; i < rowData.Length; i++)
                {
                    g.DrawRectangle(Pens.Black, colX, tableY, colWidths[i], 30);
                    g.DrawString(rowData[i], textFont, blackBrush, colX + 5, tableY + 5);
                    colX += colWidths[i];
                }

                tableY += 30;
                stt++;
            }

            y = tableY + 20;

            // 5. Tổng tiền
            g.DrawString("Tổng tiền: " + lblTongTien.Text, headerFont, blackBrush, e.PageBounds.Width - 300, y);
            y += 50;

            // 6. Ghi chú/cảm ơn
            g.DrawString("Cảm ơn quý đối tác đã cung cấp hàng!", textFont, blueBrush, (e.PageBounds.Width - 350) / 2, y);

        }
    }
}
