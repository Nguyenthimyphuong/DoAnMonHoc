﻿namespace GUI
{
    partial class GUI_HDBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GUI_HDBanHang));
            label1 = new Label();
            groupBoxDHB = new GroupBox();
            groupBox3 = new GroupBox();
            btnTimKiem = new Button();
            txtMaKHTimKiem = new TextBox();
            txtMaDHBTimKiem = new TextBox();
            maKHTimKiem = new Label();
            maDHBTimKiem = new Label();
            btnXuatExcelDHB = new Button();
            btnXoaDHB = new Button();
            lblTongTien = new Label();
            lblTenKhachHang = new Label();
            btnInHoaDonDHB = new Button();
            btnSuaDHB = new Button();
            label6 = new Label();
            btnThemDHB = new Button();
            dgvDonHangBan = new DataGridView();
            label5 = new Label();
            btnMoiDHB = new Button();
            dtpNgayBan = new DateTimePicker();
            cboMaKH = new ComboBox();
            txtMaDHB = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            nudSoLuong = new NumericUpDown();
            groupBoxChiTietDHB = new GroupBox();
            lblTenSanPham = new Label();
            label15 = new Label();
            txtMaDHBChiTiet = new TextBox();
            lblThanhTien = new Label();
            lblDonGia = new Label();
            btnXoaChiTietDHB = new Button();
            btnSuaChiTietDHB = new Button();
            btnThemChiTietDHB = new Button();
            btnMoiChiTietDHB = new Button();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            cboMaSP = new ComboBox();
            label10 = new Label();
            label9 = new Label();
            dgvChiTietDonHangBan = new DataGridView();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            groupBoxDHB.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDonHangBan).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudSoLuong).BeginInit();
            groupBoxChiTietDHB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonHangBan).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(508, 7);
            label1.Name = "label1";
            label1.Size = new Size(187, 20);
            label1.TabIndex = 0;
            label1.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // groupBoxDHB
            // 
            groupBoxDHB.Controls.Add(groupBox3);
            groupBoxDHB.Controls.Add(btnXuatExcelDHB);
            groupBoxDHB.Controls.Add(btnXoaDHB);
            groupBoxDHB.Controls.Add(lblTongTien);
            groupBoxDHB.Controls.Add(lblTenKhachHang);
            groupBoxDHB.Controls.Add(btnInHoaDonDHB);
            groupBoxDHB.Controls.Add(btnSuaDHB);
            groupBoxDHB.Controls.Add(label6);
            groupBoxDHB.Controls.Add(btnThemDHB);
            groupBoxDHB.Controls.Add(dgvDonHangBan);
            groupBoxDHB.Controls.Add(label5);
            groupBoxDHB.Controls.Add(btnMoiDHB);
            groupBoxDHB.Controls.Add(dtpNgayBan);
            groupBoxDHB.Controls.Add(cboMaKH);
            groupBoxDHB.Controls.Add(txtMaDHB);
            groupBoxDHB.Controls.Add(label4);
            groupBoxDHB.Controls.Add(label3);
            groupBoxDHB.Controls.Add(label2);
            groupBoxDHB.Location = new Point(10, 36);
            groupBoxDHB.Margin = new Padding(3, 2, 3, 2);
            groupBoxDHB.Name = "groupBoxDHB";
            groupBoxDHB.Padding = new Padding(3, 2, 3, 2);
            groupBoxDHB.Size = new Size(572, 613);
            groupBoxDHB.TabIndex = 1;
            groupBoxDHB.TabStop = false;
            groupBoxDHB.Text = "Thông tin hóa đơn";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnTimKiem);
            groupBox3.Controls.Add(txtMaKHTimKiem);
            groupBox3.Controls.Add(txtMaDHBTimKiem);
            groupBox3.Controls.Add(maKHTimKiem);
            groupBox3.Controls.Add(maDHBTimKiem);
            groupBox3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.Location = new Point(9, 491);
            groupBox3.Margin = new Padding(3, 2, 3, 2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 2, 3, 2);
            groupBox3.Size = new Size(548, 104);
            groupBox3.TabIndex = 27;
            groupBox3.TabStop = false;
            groupBox3.Text = "Tìm kiếm";
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            btnTimKiem.Location = new Point(402, 47);
            btnTimKiem.Margin = new Padding(3, 2, 3, 2);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(123, 28);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtMaKHTimKiem
            // 
            txtMaKHTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaKHTimKiem.Location = new Point(144, 70);
            txtMaKHTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaKHTimKiem.Name = "txtMaKHTimKiem";
            txtMaKHTimKiem.Size = new Size(224, 26);
            txtMaKHTimKiem.TabIndex = 3;
            // 
            // txtMaDHBTimKiem
            // 
            txtMaDHBTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            txtMaDHBTimKiem.Location = new Point(144, 30);
            txtMaDHBTimKiem.Margin = new Padding(3, 2, 3, 2);
            txtMaDHBTimKiem.Name = "txtMaDHBTimKiem";
            txtMaDHBTimKiem.Size = new Size(223, 26);
            txtMaDHBTimKiem.TabIndex = 2;
            // 
            // maKHTimKiem
            // 
            maKHTimKiem.AutoSize = true;
            maKHTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            maKHTimKiem.Location = new Point(4, 75);
            maKHTimKiem.Name = "maKHTimKiem";
            maKHTimKiem.Size = new Size(118, 20);
            maKHTimKiem.TabIndex = 1;
            maKHTimKiem.Text = "Mã khách hàng";
            // 
            // maDHBTimKiem
            // 
            maDHBTimKiem.AutoSize = true;
            maDHBTimKiem.Font = new Font("Microsoft Sans Serif", 12F);
            maDHBTimKiem.Location = new Point(9, 35);
            maDHBTimKiem.Name = "maDHBTimKiem";
            maDHBTimKiem.Size = new Size(70, 20);
            maDHBTimKiem.TabIndex = 0;
            maDHBTimKiem.Text = "Mã ĐHB";
            // 
            // btnXuatExcelDHB
            // 
            btnXuatExcelDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnXuatExcelDHB.Location = new Point(316, 442);
            btnXuatExcelDHB.Margin = new Padding(3, 2, 3, 2);
            btnXuatExcelDHB.Name = "btnXuatExcelDHB";
            btnXuatExcelDHB.Size = new Size(109, 29);
            btnXuatExcelDHB.TabIndex = 38;
            btnXuatExcelDHB.Text = "Xuất Excel";
            btnXuatExcelDHB.UseVisualStyleBackColor = true;
            btnXuatExcelDHB.Click += btnXuatExcelDHB_Click;
            // 
            // btnXoaDHB
            // 
            btnXoaDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoaDHB.Location = new Point(411, 400);
            btnXoaDHB.Margin = new Padding(3, 2, 3, 2);
            btnXoaDHB.Name = "btnXoaDHB";
            btnXoaDHB.Size = new Size(82, 29);
            btnXoaDHB.TabIndex = 36;
            btnXoaDHB.Text = "Xóa";
            btnXoaDHB.UseVisualStyleBackColor = true;
            btnXoaDHB.Click += btnXoaDHB_Click;
            // 
            // lblTongTien
            // 
            lblTongTien.AutoSize = true;
            lblTongTien.Location = new Point(122, 207);
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Size = new Size(13, 15);
            lblTongTien.TabIndex = 11;
            lblTongTien.Text = "0";
            // 
            // lblTenKhachHang
            // 
            lblTenKhachHang.AutoSize = true;
            lblTenKhachHang.Location = new Point(116, 112);
            lblTenKhachHang.Name = "lblTenKhachHang";
            lblTenKhachHang.Size = new Size(100, 15);
            lblTenKhachHang.TabIndex = 10;
            lblTenKhachHang.Text = "lblTenKhachHang";
            // 
            // btnInHoaDonDHB
            // 
            btnInHoaDonDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnInHoaDonDHB.Location = new Point(147, 442);
            btnInHoaDonDHB.Margin = new Padding(3, 2, 3, 2);
            btnInHoaDonDHB.Name = "btnInHoaDonDHB";
            btnInHoaDonDHB.Size = new Size(109, 29);
            btnInHoaDonDHB.TabIndex = 37;
            btnInHoaDonDHB.Text = "In hóa đơn";
            btnInHoaDonDHB.UseVisualStyleBackColor = true;
            btnInHoaDonDHB.Click += btnInHoaDonDHB_Click;
            // 
            // btnSuaDHB
            // 
            btnSuaDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnSuaDHB.Location = new Point(292, 400);
            btnSuaDHB.Margin = new Padding(3, 2, 3, 2);
            btnSuaDHB.Name = "btnSuaDHB";
            btnSuaDHB.Size = new Size(82, 29);
            btnSuaDHB.TabIndex = 35;
            btnSuaDHB.Text = "Sửa";
            btnSuaDHB.UseVisualStyleBackColor = true;
            btnSuaDHB.Click += btnSuaDHB_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(5, 112);
            label6.Name = "label6";
            label6.Size = new Size(90, 15);
            label6.TabIndex = 9;
            label6.Text = "Tên khách hàng";
            // 
            // btnThemDHB
            // 
            btnThemDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnThemDHB.Location = new Point(186, 400);
            btnThemDHB.Margin = new Padding(3, 2, 3, 2);
            btnThemDHB.Name = "btnThemDHB";
            btnThemDHB.Size = new Size(82, 29);
            btnThemDHB.TabIndex = 34;
            btnThemDHB.Text = "Thêm";
            btnThemDHB.UseVisualStyleBackColor = true;
            btnThemDHB.Click += btnThemDHB_Click;
            // 
            // dgvDonHangBan
            // 
            dgvDonHangBan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDonHangBan.Location = new Point(6, 241);
            dgvDonHangBan.Margin = new Padding(3, 2, 3, 2);
            dgvDonHangBan.Name = "dgvDonHangBan";
            dgvDonHangBan.RowHeadersWidth = 51;
            dgvDonHangBan.Size = new Size(550, 141);
            dgvDonHangBan.TabIndex = 8;
            dgvDonHangBan.CellClick += dgvDonHangBan_CellClick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 207);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 6;
            label5.Text = "Tổng tiền";
            // 
            // btnMoiDHB
            // 
            btnMoiDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoiDHB.Location = new Point(80, 400);
            btnMoiDHB.Margin = new Padding(3, 2, 3, 2);
            btnMoiDHB.Name = "btnMoiDHB";
            btnMoiDHB.Size = new Size(82, 29);
            btnMoiDHB.TabIndex = 33;
            btnMoiDHB.Text = "Mới";
            btnMoiDHB.UseVisualStyleBackColor = true;
            btnMoiDHB.Click += btnMoiDHB_Click;
            // 
            // dtpNgayBan
            // 
            dtpNgayBan.CustomFormat = "dd-MM-yyyy";
            dtpNgayBan.Format = DateTimePickerFormat.Custom;
            dtpNgayBan.Location = new Point(122, 155);
            dtpNgayBan.Margin = new Padding(3, 2, 3, 2);
            dtpNgayBan.Name = "dtpNgayBan";
            dtpNgayBan.Size = new Size(219, 23);
            dtpNgayBan.TabIndex = 5;
            // 
            // cboMaKH
            // 
            cboMaKH.FormattingEnabled = true;
            cboMaKH.Location = new Point(119, 69);
            cboMaKH.Margin = new Padding(3, 2, 3, 2);
            cboMaKH.Name = "cboMaKH";
            cboMaKH.Size = new Size(133, 23);
            cboMaKH.TabIndex = 4;
            cboMaKH.SelectedIndexChanged += cboMaKH_SelectedIndexChanged;
            // 
            // txtMaDHB
            // 
            txtMaDHB.Location = new Point(122, 26);
            txtMaDHB.Margin = new Padding(3, 2, 3, 2);
            txtMaDHB.Name = "txtMaDHB";
            txtMaDHB.Size = new Size(130, 23);
            txtMaDHB.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 159);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 2;
            label4.Text = "Ngày bán";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 75);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 1;
            label3.Text = "Mã khách hàng *";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 28);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 0;
            label2.Text = "Mã ĐHB *";
            // 
            // nudSoLuong
            // 
            nudSoLuong.Location = new Point(425, 32);
            nudSoLuong.Margin = new Padding(3, 2, 3, 2);
            nudSoLuong.Name = "nudSoLuong";
            nudSoLuong.Size = new Size(131, 23);
            nudSoLuong.TabIndex = 39;
            nudSoLuong.ValueChanged += nudSoLuong_ValueChanged;
            // 
            // groupBoxChiTietDHB
            // 
            groupBoxChiTietDHB.Controls.Add(nudSoLuong);
            groupBoxChiTietDHB.Controls.Add(lblTenSanPham);
            groupBoxChiTietDHB.Controls.Add(label15);
            groupBoxChiTietDHB.Controls.Add(txtMaDHBChiTiet);
            groupBoxChiTietDHB.Controls.Add(lblThanhTien);
            groupBoxChiTietDHB.Controls.Add(lblDonGia);
            groupBoxChiTietDHB.Controls.Add(btnXoaChiTietDHB);
            groupBoxChiTietDHB.Controls.Add(btnSuaChiTietDHB);
            groupBoxChiTietDHB.Controls.Add(btnThemChiTietDHB);
            groupBoxChiTietDHB.Controls.Add(btnMoiChiTietDHB);
            groupBoxChiTietDHB.Controls.Add(label13);
            groupBoxChiTietDHB.Controls.Add(label12);
            groupBoxChiTietDHB.Controls.Add(label11);
            groupBoxChiTietDHB.Controls.Add(cboMaSP);
            groupBoxChiTietDHB.Controls.Add(label10);
            groupBoxChiTietDHB.Controls.Add(label9);
            groupBoxChiTietDHB.Controls.Add(dgvChiTietDonHangBan);
            groupBoxChiTietDHB.Location = new Point(604, 36);
            groupBoxChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            groupBoxChiTietDHB.Name = "groupBoxChiTietDHB";
            groupBoxChiTietDHB.Padding = new Padding(3, 2, 3, 2);
            groupBoxChiTietDHB.Size = new Size(600, 613);
            groupBoxChiTietDHB.TabIndex = 2;
            groupBoxChiTietDHB.TabStop = false;
            groupBoxChiTietDHB.Text = "Chi tiết hóa đơn";
            // 
            // lblTenSanPham
            // 
            lblTenSanPham.AutoSize = true;
            lblTenSanPham.Location = new Point(109, 126);
            lblTenSanPham.Name = "lblTenSanPham";
            lblTenSanPham.Size = new Size(0, 15);
            lblTenSanPham.TabIndex = 44;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(5, 126);
            label15.Name = "label15";
            label15.Size = new Size(80, 15);
            label15.TabIndex = 43;
            label15.Text = "Tên sản phẩm";
            // 
            // txtMaDHBChiTiet
            // 
            txtMaDHBChiTiet.Location = new Point(109, 32);
            txtMaDHBChiTiet.Margin = new Padding(3, 2, 3, 2);
            txtMaDHBChiTiet.Name = "txtMaDHBChiTiet";
            txtMaDHBChiTiet.Size = new Size(130, 23);
            txtMaDHBChiTiet.TabIndex = 39;
            // 
            // lblThanhTien
            // 
            lblThanhTien.AutoSize = true;
            lblThanhTien.Location = new Point(461, 126);
            lblThanhTien.Name = "lblThanhTien";
            lblThanhTien.Size = new Size(13, 15);
            lblThanhTien.TabIndex = 42;
            lblThanhTien.Text = "0";
            // 
            // lblDonGia
            // 
            lblDonGia.AutoSize = true;
            lblDonGia.Location = new Point(461, 82);
            lblDonGia.Name = "lblDonGia";
            lblDonGia.Size = new Size(13, 15);
            lblDonGia.TabIndex = 41;
            lblDonGia.Text = "0";
            // 
            // btnXoaChiTietDHB
            // 
            btnXoaChiTietDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnXoaChiTietDHB.Location = new Point(425, 561);
            btnXoaChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            btnXoaChiTietDHB.Name = "btnXoaChiTietDHB";
            btnXoaChiTietDHB.Size = new Size(82, 29);
            btnXoaChiTietDHB.TabIndex = 40;
            btnXoaChiTietDHB.Text = "Xóa";
            btnXoaChiTietDHB.UseVisualStyleBackColor = true;
            btnXoaChiTietDHB.Click += btnXoaChiTietDHB_Click;
            // 
            // btnSuaChiTietDHB
            // 
            btnSuaChiTietDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnSuaChiTietDHB.Location = new Point(306, 561);
            btnSuaChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            btnSuaChiTietDHB.Name = "btnSuaChiTietDHB";
            btnSuaChiTietDHB.Size = new Size(82, 29);
            btnSuaChiTietDHB.TabIndex = 39;
            btnSuaChiTietDHB.Text = "Sửa";
            btnSuaChiTietDHB.UseVisualStyleBackColor = true;
            btnSuaChiTietDHB.Click += btnSuaChiTietDHB_Click;
            // 
            // btnThemChiTietDHB
            // 
            btnThemChiTietDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnThemChiTietDHB.Location = new Point(200, 561);
            btnThemChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            btnThemChiTietDHB.Name = "btnThemChiTietDHB";
            btnThemChiTietDHB.Size = new Size(82, 29);
            btnThemChiTietDHB.TabIndex = 38;
            btnThemChiTietDHB.Text = "Thêm";
            btnThemChiTietDHB.UseVisualStyleBackColor = true;
            btnThemChiTietDHB.Click += btnThemChiTietDHB_Click;
            // 
            // btnMoiChiTietDHB
            // 
            btnMoiChiTietDHB.Font = new Font("Microsoft Sans Serif", 12F);
            btnMoiChiTietDHB.Location = new Point(94, 561);
            btnMoiChiTietDHB.Margin = new Padding(3, 2, 3, 2);
            btnMoiChiTietDHB.Name = "btnMoiChiTietDHB";
            btnMoiChiTietDHB.Size = new Size(82, 29);
            btnMoiChiTietDHB.TabIndex = 37;
            btnMoiChiTietDHB.Text = "Mới";
            btnMoiChiTietDHB.UseVisualStyleBackColor = true;
            btnMoiChiTietDHB.Click += btnMoiChiTietDHB_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(347, 126);
            label13.Name = "label13";
            label13.Size = new Size(63, 15);
            label13.TabIndex = 8;
            label13.Text = "Thành tiền";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(347, 82);
            label12.Name = "label12";
            label12.Size = new Size(48, 15);
            label12.TabIndex = 7;
            label12.Text = "Đơn giá";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(347, 34);
            label11.Name = "label11";
            label11.Size = new Size(54, 15);
            label11.TabIndex = 6;
            label11.Text = "Số lượng";
            // 
            // cboMaSP
            // 
            cboMaSP.FormattingEnabled = true;
            cboMaSP.Location = new Point(109, 75);
            cboMaSP.Margin = new Padding(3, 2, 3, 2);
            cboMaSP.Name = "cboMaSP";
            cboMaSP.Size = new Size(133, 23);
            cboMaSP.TabIndex = 5;
            cboMaSP.SelectedIndexChanged += cboMaSP_SelectedIndexChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(5, 77);
            label10.Name = "label10";
            label10.Size = new Size(87, 15);
            label10.TabIndex = 4;
            label10.Text = "Mã sản phẩm *";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(5, 37);
            label9.Name = "label9";
            label9.Size = new Size(59, 15);
            label9.TabIndex = 1;
            label9.Text = "Mã ĐHB *";
            // 
            // dgvChiTietDonHangBan
            // 
            dgvChiTietDonHangBan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvChiTietDonHangBan.Location = new Point(5, 173);
            dgvChiTietDonHangBan.Margin = new Padding(3, 2, 3, 2);
            dgvChiTietDonHangBan.Name = "dgvChiTietDonHangBan";
            dgvChiTietDonHangBan.RowHeadersWidth = 51;
            dgvChiTietDonHangBan.Size = new Size(590, 340);
            dgvChiTietDonHangBan.TabIndex = 0;
            dgvChiTietDonHangBan.CellClick += dgvChiTietDonHangBan_CellClick;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // GUI_HDBanHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1283, 722);
            Controls.Add(groupBoxChiTietDHB);
            Controls.Add(groupBoxDHB);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GUI_HDBanHang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GUI_HDBanHang";
            Load += GUI_HDBanHang_Load;
            groupBoxDHB.ResumeLayout(false);
            groupBoxDHB.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDonHangBan).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudSoLuong).EndInit();
            groupBoxChiTietDHB.ResumeLayout(false);
            groupBoxChiTietDHB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonHangBan).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBoxDHB;
        private GroupBox groupBoxChiTietDHB;
        private DataGridView dgvDonHangBan;
        private Label label5;
        private DateTimePicker dtpNgayBan;
        private ComboBox cboMaKH;
        private TextBox txtMaDHB;
        private Label label4;
        private Label label3;
        private Label label2;
        private DataGridView dgvChiTietDonHangBan;
        private Label label6;
        private Label lblTongTien;
        private Label lblTenKhachHang;
        private Button btnXoaDHB;
        private Button btnInHoaDonDHB;
        private Button btnSuaDHB;
        private Button btnThemDHB;
        private Button btnMoiDHB;
        private Button btnXuatExcelDHB;
        private GroupBox groupBox3;
        private Button btnTimKiem;
        private TextBox txtMaKHTimKiem;
        private TextBox txtMaDHBTimKiem;
        private Label maKHTimKiem;
        private Label maDHBTimKiem;
        private Label label9;
        private Label label13;
        private Label label12;
        private Label label11;
        private ComboBox cboMaSP;
        private Label label10;
        private Button btnXoaChiTietDHB;
        private Button btnSuaChiTietDHB;
        private Button btnThemChiTietDHB;
        private Button btnMoiChiTietDHB;
        private Label lblThanhTien;
        private Label lblDonGia;
        private TextBox txtMaDHBChiTiet;
        private Label lblTenSanPham;
        private Label label15;
        private NumericUpDown nudSoLuong;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
    }
}