﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_DonHangBan
    {
        private DAL_DonHangBan dalDonHangBan;

        public BLL_DonHangBan()
        {
            this.dalDonHangBan = new DAL_DonHangBan();
        }

        public BLL_DonHangBan(DAL_DonHangBan dal)
        {
            this.dalDonHangBan = dal;
        }

        // Lấy tất cả đơn hàng bán
        public DataTable GetAllDonHangBan()
        {
            return dalDonHangBan.GetAllDonHangBan();
        }

        // Thêm đơn hàng bán
        public bool ThemDonHangBan(DTO_DonHangBan donHang)
        {
            return dalDonHangBan.ThemDonHangBan(donHang);
        }

        // Sửa đơn hàng bán
        public bool SuaDonHangBan(DTO_DonHangBan donHang)
        {
            return dalDonHangBan.SuaDonHangBan(donHang);
        }

        // Xóa đơn hàng bán
        public bool XoaDonHangBan(string maDHB)
        {
            return dalDonHangBan.XoaDonHangBan(maDHB);
        }

        // Tìm kiếm đơn hàng bán
        public DataTable TimKiemDonHangBan(string maDHB, string maKH)
        {
            return dalDonHangBan.TimKiemDonHangBan(maDHB, maKH);
        }
    }
}
