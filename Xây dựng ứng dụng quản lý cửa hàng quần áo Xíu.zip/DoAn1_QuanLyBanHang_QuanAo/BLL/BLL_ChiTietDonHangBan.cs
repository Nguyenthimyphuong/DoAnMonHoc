﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_ChiTietDonHangBan
    {
        private DAL_ChiTietDonHangBan dalChiTiet;

        public BLL_ChiTietDonHangBan()
        {
            this.dalChiTiet = new DAL_ChiTietDonHangBan();
        }

        public BLL_ChiTietDonHangBan(DAL_ChiTietDonHangBan dal)
        {
            this.dalChiTiet = dal;
        }

        // Lấy tất cả chi tiết đơn hàng bán
        public DataTable GetAllChiTietDonHangBan()
        {
            return dalChiTiet.GetAllChiTietDonHangBan();
        }

        // Lấy chi tiết đơn hàng theo mã đơn hàng
        public DataTable GetChiTietTheoMaDHB(string maDHB)
        {
            return dalChiTiet.GetChiTietTheoMaDHB(maDHB);
        }

        // Thêm chi tiết đơn hàng bán
        public bool ThemChiTietDonHangBan(DTO_ChiTietDonHangBan chitiet)
        {
            return dalChiTiet.ThemChiTiet(chitiet);
        }

        // Sửa chi tiết đơn hàng bán
        public bool SuaChiTietDonHangBan(DTO_ChiTietDonHangBan chitiet)
        {
            return dalChiTiet.SuaChiTiet(chitiet);
        }

        // Xóa chi tiết đơn hàng bán theo mã đơn hàng và mã sản phẩm
        public bool XoaChiTietDonHangBan(string maDHB, string maSP)
        {
            return dalChiTiet.XoaChiTiet(maDHB, maSP);
        }

        // Tính tổng tiền đơn hàng theo mã đơn
        public decimal TinhTongTienTheoMaDHB(string maDHB)
        {
            return dalChiTiet.TinhTongTienTheoMaDHB(maDHB);
        }
    }
}
