﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class BLL_NhanVien
    {
        private DAL_NhanVien dalNhanVien;

        // Constructor không tham số
        public BLL_NhanVien()
        {
            this.dalNhanVien = new DAL_NhanVien();
        }

        // Constructor có tham số
        public BLL_NhanVien(DAL_NhanVien dalNhanVien)
        {
            this.dalNhanVien = dalNhanVien;
        }

        // Lấy tất cả nhân viên
        public DataTable GetAllNhanVien()
        {
            return dalNhanVien.GetAllNhanVien();
        }

        // Thêm nhân viên
        public bool ThemNhanVien(DTO_NhanVien nhanVien)
        {
            return dalNhanVien.ThemNhanVien(nhanVien);
        }

        // Sửa nhân viên
        public bool SuaNhanVien(DTO_NhanVien nhanVien)
        {
            return dalNhanVien.SuaNhanVien(nhanVien);
        }

        // Xóa nhân viên
        public bool XoaNhanVien(string maNV)
        {
            return dalNhanVien.XoaNhanVien(maNV);
        }

        // Tìm kiếm nhân viên
        public DataTable TimKiemNhanVien(string maNV, string tenNV)
        {
            return dalNhanVien.TimKiemNhanVien(maNV, tenNV);
        }
    }
}