﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_BaoCaoDoanhThu
    {
        private DAL_BaoCaoDoanhThu baoCaoDAL;

        public BLL_BaoCaoDoanhThu()
        {
            baoCaoDAL = new DAL_BaoCaoDoanhThu();
        }

        public BLL_BaoCaoDoanhThu(DAL_BaoCaoDoanhThu dal)
        {
            baoCaoDAL = dal;
        }

        public DataTable LayDoanhThuTheoNgay(DateTime ngay)
        {
            return baoCaoDAL.GetDoanhThuTheoNgay(ngay);
        }

        public DataTable LayDoanhThuTheoThang(int thang, int nam)
        {
            return baoCaoDAL.GetDoanhThuTheoThang(thang, nam);
        }

        public DataTable LayDoanhThuTheoNam(int nam)
        {
            return baoCaoDAL.GetDoanhThuTheoNam(nam);
        }

        public decimal TinhTongDoanhThu(DataTable dt)
        {
            decimal tong = 0;
            foreach (DataRow row in dt.Rows)
            {
                tong += Convert.ToDecimal(row["TongTien"]);
            }
            return tong;
        }
    }
}
