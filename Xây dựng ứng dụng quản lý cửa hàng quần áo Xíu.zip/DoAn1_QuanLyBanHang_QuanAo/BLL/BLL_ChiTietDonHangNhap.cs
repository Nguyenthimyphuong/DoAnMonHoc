﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_ChiTietDonHangNhap
    {
        private DAL_ChiTietDonHangNhap dalChiTiet;

        public BLL_ChiTietDonHangNhap()
        {
            this.dalChiTiet = new DAL_ChiTietDonHangNhap();
        }

        public BLL_ChiTietDonHangNhap(DAL_ChiTietDonHangNhap dal)
        {
            this.dalChiTiet = dal;
        }

        // Lấy tất cả chi tiết đơn hàng nhập
        public DataTable GetAllChiTietDonHangNhap()
        {
            return dalChiTiet.GetAllChiTietDonHangNhap();
        }

        // Lấy chi tiết đơn hàng nhập theo mã đơn hàng
        public DataTable GetChiTietTheoMaDHN(string maDHN)
        {
            return dalChiTiet.GetChiTietTheoMaDHN(maDHN);
        }

        // Thêm chi tiết đơn hàng nhập
        public bool ThemChiTietDonHangNhap(DTO_ChiTietDonHangNhap chitiet)
        {
            return dalChiTiet.ThemChiTiet(chitiet);
        }

        // Sửa chi tiết đơn hàng nhập
        public bool SuaChiTietDonHangNhap(DTO_ChiTietDonHangNhap chitiet)
        {
            return dalChiTiet.SuaChiTiet(chitiet);
        }

        // Xóa chi tiết đơn hàng nhập theo mã đơn hàng và mã sản phẩm
        public bool XoaChiTietDonHangNhap(string maDHN, string maSP)
        {
            return dalChiTiet.XoaChiTiet(maDHN, maSP);
        }

        // Tính tổng tiền đơn hàng nhập theo mã đơn
        public decimal TinhTongTienTheoMaDHN(string maDHN)
        {
            return dalChiTiet.TinhTongTienTheoMaDHN(maDHN);
        }
    }
}
