﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_DonHangNhap
    {
        private DAL_DonHangNhap dalDonHangNhap;

        public BLL_DonHangNhap()
        {
            this.dalDonHangNhap = new DAL_DonHangNhap();
        }

        public BLL_DonHangNhap(DAL_DonHangNhap dal)
        {
            this.dalDonHangNhap = dal;
        }

        // Lấy tất cả đơn hàng nhập
        public DataTable GetAllDonHangNhap()
        {
            return dalDonHangNhap.GetAllDonHangNhap();
        }

        // Thêm đơn hàng nhập
        public bool ThemDonHangNhap(DTO_DonHangNhap donHang)
        {
            return dalDonHangNhap.ThemDonHangNhap(donHang);
        }

        // Sửa đơn hàng nhập
        public bool SuaDonHangNhap(DTO_DonHangNhap donHang)
        {
            return dalDonHangNhap.SuaDonHangNhap(donHang);
        }

        // Xóa đơn hàng nhập
        public bool XoaDonHangNhap(string maDHN)
        {
            return dalDonHangNhap.XoaDonHangNhap(maDHN);
        }

        // Tìm kiếm đơn hàng nhập
        public DataTable TimKiemDonHangNhap(string maDHN, string maNCC)
        {
            return dalDonHangNhap.TimKiemDonHangNhap(maDHN, maNCC);
        }
    }
}
